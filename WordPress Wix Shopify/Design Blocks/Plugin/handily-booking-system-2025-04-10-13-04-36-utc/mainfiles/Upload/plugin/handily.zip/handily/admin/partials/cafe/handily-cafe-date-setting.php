<?php
/***
 * Handily Custom Post Type For Create Schedule 
 */
$r_labels = array(
    'name' => esc_html__( 'Handily Cafe Dete Setting', 'handily' ),
    'singular_name' => esc_html__( 'Handily Cafe Dete Setting', 'handily' ),
    'menu_name'  => esc_html__( 'Handily Cafe Dete Setting', 'admin menu', 'handily' ),
    'name_admin_bar' => _x( 'Handily Cafe Dete Setting', 'add new on admin bar', 'handily' ),
    'add_new' => _x( 'Add New', 'Cafe Dete Setting', 'handily' ),
    'add_new_item' => esc_html__( 'Add New Cafe Dete Setting', 'handily' ),
    'new_item'  => esc_html__( 'New Cafe Dete Setting', 'handily' ),
    'edit_item' => esc_html__( 'Edit Cafe Dete Setting', 'handily' ),
    'view_item' => esc_html__( 'View Cafe Dete Setting', 'handily' ),
    'all_items' => esc_html__( 'All Cafe Dete Setting', 'handily' ),
    'search_items' => esc_html__( 'Search Cafe Dete Setting', 'handily' ),
    'parent_item_colon'  => esc_html__( 'Parent Cafe Dete Setting:', 'handily' ),
    'not_found' => esc_html__( 'No Cafe Dete Setting found.', 'handily' ),
    'not_found_in_trash' => esc_html__( 'No Cafe Dete Setting found in Trash.', 'handily' )
   );
$hr_args = array(
    'labels'             => $r_labels,
    'description'        => esc_html__( 'Description.', 'handily' ),
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => false,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'cafe_date' ),
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'menu_icon'          => 'dashicons-video-alt3',
    'supports'           => array( 'title')
   );
register_post_type('cafe_date', $hr_args );  