<?php
/***
 * Handily Custom Post Type For Create Room
 */
$r_labels = array(
    'name' => esc_html__( 'Handily Rooms', 'handily' ),
    'singular_name' => esc_html__( 'Handily Rooms', 'handily' ),
    'menu_name'  => esc_html__( 'Handily Rooms', 'admin menu', 'handily' ),
    'name_admin_bar' => _x( 'Handily Rooms', 'add new on admin bar', 'handily' ),
    'add_new' => _x( 'Add New', 'Rooms', 'handily' ),
    'add_new_item' => esc_html__( 'Add New Room', 'handily' ),
    'new_item'  => esc_html__( 'New Room', 'handily' ),
    'edit_item' => esc_html__( 'Edit Room', 'handily' ),
    'view_item' => esc_html__( 'View Room', 'handily' ),
    'all_items' => esc_html__( 'All Room', 'handily' ),
    'search_items' => esc_html__( 'Search Room', 'handily' ),
    'parent_item_colon'  => esc_html__( 'Parent Room:', 'handily' ),
    'not_found' => esc_html__( 'No Room found.', 'handily' ),
    'not_found_in_trash' => esc_html__( 'No Room found in Trash.', 'handily' )
   );

   $hr_args = array(
    'labels'             => $r_labels,
    'description'        => esc_html__( 'Description.', 'handily' ),
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => false,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'rooms' ),
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'menu_icon'          => 'dashicons-video-alt3',
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt')
   );
  register_post_type( 'rooms', $hr_args );
  /* Add new taxonomy, make it hierarchical (like categories) */
   $rty_labels = array(
      'name'              => esc_html__( 'Room Types', 'handily' ),
      'singular_name'     => esc_html__( 'Room Type', 'handily' ),
      'search_items'      => esc_html__( 'Search Room Types', 'handily' ),
      'all_items'         => esc_html__( 'All Room Types', 'handily' ),
      'parent_item'       => esc_html__( 'Parent Room Type', 'handily' ),
      'parent_item_colon' => esc_html__( 'Parent Room Type:', 'handily' ),
      'edit_item'         => esc_html__( 'Edit Room Type', 'handily' ),
      'update_item'       => esc_html__( 'Update Room Type', 'handily' ),
      'add_new_item'      => esc_html__( 'Add New Room Type', 'handily' ),
      'new_item_name'     => esc_html__( 'New Room Type Name', 'handily' ),
      'menu_name'         => esc_html__( 'Room Type', 'handily' ),
    );

   $rty_args = array(
      'hierarchical'      => true,
      'labels'            => $rty_labels,
      'show_ui'           => true,
      'show_admin_column' => true,
      'query_var'         => true,
      'rewrite'           => array('slug' => 'room-type'),
   );
register_taxonomy('room-type', array('rooms'), $rty_args ); 

/**
 * Hotel Facilities
 */ 
$rty_labels = array(
   'name'              => esc_html__( 'Hotel Facilities', 'handily' ),
   'singular_name'     => esc_html__( 'Hotel Facilities', 'handily' ),
   'search_items'      => esc_html__( 'Search Hotel Facilities', 'handily' ),
   'all_items'         => esc_html__( 'All Hotel Facilities', 'handily' ),
   'parent_item'       => esc_html__( 'Parent Hotel Facilities', 'handily' ),
   'parent_item_colon' => esc_html__( 'Parent Hotel Facilities:', 'handily' ),
   'edit_item'         => esc_html__( 'Edit Hotel Facilities', 'handily' ),
   'update_item'       => esc_html__( 'Update Hotel Facilities', 'handily' ),
   'add_new_item'      => esc_html__( 'Add New Hotel Facilities', 'handily' ),
   'new_item_name'     => esc_html__( 'New Hotel Facilities Name', 'handily' ),
   'menu_name'         => esc_html__( 'Hotel Facilities', 'handily' ),
 );
$rty_args = array(
   'hierarchical'      => true,
   'labels'            => $rty_labels,
   'show_ui'           => true,
   'show_admin_column' => true,
   'query_var'         => true,
   'rewrite'           => array('slug' => 'hotel-facilities'),
); 
register_taxonomy('hotel-facilities', array('rooms'), $rty_args ); 

//Register Meta box
add_action('add_meta_boxes',function (){
    add_meta_box(
         'room-type-mange',     
         'Manage Room Type',     
         'mange_room_type_link',     
         ['rooms'],     
         'side' 
    );
	add_meta_box(
         'hotel-facilities-mange',     
         'Manage Hotel Facilities',     
         'mange_hotel_facilities',     
         ['rooms'],     
         'side'
    );
});

//Meta callback function
function mange_room_type_link($post){
    $cs_meta_val=get_post_meta($post->ID);

    ?>
    <div class="room_type_link">
		<a href="<?php echo get_admin_url();?>edit-tags.php?taxonomy=room-type&post_type=room"><?php echo esc_html('Manage Room Type', 'handily');?></a>
	</div>
    <?php     
}

//Meta callback function
function mange_hotel_facilities($post){
    $cs_meta_val=get_post_meta($post->ID);

    ?>
    <div class="facilities_link">
		<a href="<?php echo get_admin_url();?>edit-tags.php?taxonomy=hotel-facilities&post_type=room"><?php echo esc_html('Manage Hotel Facilities', 'handily');?></a>
	</div>
    <?php     
}
