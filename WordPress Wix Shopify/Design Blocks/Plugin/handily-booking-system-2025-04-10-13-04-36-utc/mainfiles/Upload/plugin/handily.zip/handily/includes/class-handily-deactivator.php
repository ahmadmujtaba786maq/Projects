<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://codecanyon.net/user/kamleshyadav
 * @since      1.0.0
 *
 * @package    Handily
 * @subpackage Handily/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Handily
 * @subpackage Handily/includes
 * @author     kamleshyadav <kamlesh.yadav@himanshusofttech.com >
 */
class Handily_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
