<?php 
require_once( dirname(__FILE__) . '/../../../../wp-load.php' ); // WP environment
require_once( dirname(__FILE__) . '/striplibary/init.php' ); // I placed the directory with Stripe PHP library in the theme folder
if(isset($_POST['stripeToken'])){
    /* we specified this parameter as a hidden field */
    require_once plugin_dir_path( dirname( __FILE__ ) ). 'Twilio/autoload.php';
    $room_id = $_POST['item_id']; 
    $room_price = $actual_price = get_post_meta($room_id,'hotel_room_price',true);
	$stripe_secretkey = get_option('stripe_secret_key');
	
	if(!empty($_POST['new_price'])){
	     $room_price = $_POST['new_price'];
	}
    $currency = get_option('curreny_val'); 
    //$currency = 'USD';
    $start_date = ''; 
    if(isset($_POST['check_in'])):
    $start_date = $_POST['check_in'];
    endif;
    $end_date = '';
    if(isset($_POST['check_out'])):
    $end_date = $_POST['check_out'];
    endif;
    $first_name = '';
    if(isset($_POST['first_name'])):
    $first_name = $_POST['first_name'];
    endif;
    $last_name = '';
    if(isset($_POST['last_name'])):
    $last_name = $_POST['last_name'];
    endif;
    $eamil = '';
    if(isset($_POST['eamil'])):
    $eamil = $_POST['eamil'];
    endif;
    $contact_number = '';
    if(isset($_POST['contact_number'])):
    $contact_number = $_POST['contact_number'];
    endif;
    $adults = '';
    if(isset($_POST['badults'])):
    $adults = $_POST['badults'];
    endif;
    $children = '';
    if(isset($_POST['bchildren'])):
    $children = $_POST['bchildren'];
    endif;
    $num_of_peoples = '';
    if(isset($_POST['num_of_peoples'])):
    $num_of_peoples = $_POST['num_of_peoples'];
    endif;
    $address = '';
    if(isset($_POST['address'])):
    $address = $_POST['address'];
    endif;
    $requirement = '';
    $requests = '';
 
	\Stripe\Stripe::setApiKey($stripe_secretkey);
    /* if your plugin price looks like 9.59, then you need to *100 it */
    $price = $room_price*100;
    try {
	    
        if(!isset($_POST['stripeToken']))
			throw new Exception('The Stripe Token is not correct');
			
			/* make a charge */
			$rdata = \Stripe\Charge::create( array( 'amount' => $price, 'currency' => $currency, 'source' => $_POST['stripeToken'], 'description' => 'User Name' .$first_name." ".$last_name.') User EMail: ' . $_POST['stripeEmail'] ) );
			if($rdata): 
			global $wpdb; 
			$tbl_pay = $wpdb->prefix. 'hotel_room_booked';
			$tranx_amount = $price/100;
			$tranx_id = $rdata->balance_transaction;
			$tranx_status = $rdata->status;
			$user_id = '1';
			$user_ID = get_current_user_id(); 
			if(empty($user_ID)){
				$user_ID = 1;
			}
			$wpdb->insert( 
				$tbl_pay, 
				array(
					'b_user_id' => $user_ID, 
					'b_room_id' => $room_id, 
					'b_start_date' => $start_date, 
					'b_end_date' => $end_date, 
					'b_adults' => $adults, 
					'b_children' => $children, 
					'b_requirement' => $requirement, 
					'b_requests' => $requests, 
					'b_txnid' => $tranx_id, 
					'b_payment_amount' => $room_price, 
					'b_payment_status' => $tranx_status, 
					'b_timestamp' => date('Y-m-d H:i:s'), 
					'b_customer_details'=> json_encode($_POST), 
					'b_payment_getway' => 'Stripe', 
					'b_hash' => 'testmode',
				   )
			); 
	
		if($wpdb->insert_id){
					$string_a = array();
					$string_a[0] = '[{payment_id}]';
					$string_a[1] = '[{first_name}]';
					$string_a[2] = '[{last_name}]';
					$string_a[3] = '[{peoples}]';
					$string_a[4] = '[{price}]';
					$string_a[5] = '[{check_in}]';
					$string_a[6] = '[{check_out}]';
					$string_a[7] = '[{adults}]';
					$string_a[8] = '[{children}]';
					$string_a[9] = '[{phone}]';
					$string_a[10] = '[{eamil}]';
					$string_a[11] = '[{total_price}]';
					$string_a[12] = '[{tax_name}]';
					$string_a[13] = '[{text_percent}]';
					
					$string_b = array();
					$string_b[0] = $tranx_id;
					$string_b[1] = $first_name;
					$string_b[2] = $last_name;
					$string_b[3] = $num_of_peoples;
					$string_b[4] = $actual_price;
					$string_b[5] = $start_date;
					$string_b[6] = $end_date;
					$string_b[7] = $adults;
					$string_b[8] = $children;
					$string_b[9] = $contact_number;
					$string_b[10] = $eamil;
					$string_b[11] = $_POST['new_price'];
					$string_b[12] = $_POST['tax_name_n'];
					$string_b[13] = $_POST['text_percent_n'];
			
					$mail_msg = get_option('email_content');
					$email_h = get_option('email_h');
					$email_sub = get_option('email_sub');
					
					if(!empty($mail_msg)){
							$html = preg_replace($string_a, $string_b, $mail_msg);
					} else{
						   $html = '<div class="mail_template">
								<h1>'. $email_h .'</h1>
								<h4>'. esc_html__('Welcome to Handily Booking system', 'Handly'). '</h4>
								<h6>'. esc_html__('Invocie #Order', 'Handly'). ' ' . $tranx_id. '<h6>
								<p>'. esc_html__('Congratulations for the successful booking for the', 'Handly'). ' '. $num_of_peoples .' '. esc_html__('people on dated', 'Handly'). ' ' . $start_date . ' '. esc_html__('to', 'Handly'). ' ' . $end_date . ''.esc_html__('Enjoy your journey / trip.', 'Handly') .'</p>
							</div>';
					}
					
					$web_url =$html;
					$header = '';
					$emailmessage = $email_sub;  
					$customer_email = $_POST['eamil'];
					$admin_email = get_option('admin_email');
					$headers = array('Content-Type: text/html; charset=UTF-8',$header); 
					$multiple_emails = array(
						$admin_email, 
						$customer_email,
					);
					wp_mail($multiple_emails, $emailmessage, $web_url, $headers);
					
							
					$sid = get_option('acsid');
					if(!empty($sid)){
					$token  = get_option('auth_token');
					$virfynumber  = get_option('ac_phone');
			
					$twilio = new Twilio\Rest\Client($sid, $token);
					$message = $twilio->messages 
					  ->create("+91".$contact_number, // to 
							   array(  
								   "messagingServiceSid" => get_option('ac_mssid'),      
								   "body" => 'Welcome to Handily Booking system. Congratulations for the successful booking. Enjoy  your journey/ trip',
							   ) 
					  ); 
			$message->sid;
					}
			$success_url = get_option('stripe_success_url').'/?invoice='.base64_encode($wpdb->insert_id);
			
			wp_safe_redirect($success_url);  
			
    		}else{ 
    		   echo esc_html__('Something Went Wrong!','handily');
    		   $cancel_url = get_option('stripe_cancel_url');
    		   wp_safe_redirect($cancel_url);
    		} 
    	endif; 

    } catch (Exception $e) {
    /**
     * if something goes wrong
     */ 
    echo $e->getMessage();
    } 
    
    
}else{
	esc_html_e('The Stripe Token is not correct','handily');
}