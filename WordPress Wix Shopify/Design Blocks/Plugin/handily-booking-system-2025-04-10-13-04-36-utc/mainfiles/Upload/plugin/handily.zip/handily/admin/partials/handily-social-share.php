<div class="hl-main-wraper">
   <div class="container-fluid">
        <div class="hl-card-body">
        <h1 class="hl-heading-title"><?php echo esc_html__('Social Share','handily'); ?></h1>
        <div class="row">
            <div class="col-lg-12">
              <div class="hl-social-network-list">
                <ul>
                       <li>
                        <a href="<?php echo esc_url('https://www.facebook.com/sharer/sharer.php?u='.home_url()); ?>" id="facebook" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/facebook_img.png'); ?>" alt="<?php echo esc_attr__('Facebook','handily'); ?>">
                            <span><?php echo esc_html__('Facebook','handily'); ?></span>
                        </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.facebook.com/dialog/send?app_id=329829260786620&amp;link='.home_url()); ?>" id="facebook_messenger" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/facebook_messengerimg.png'); ?>" alt="<?php echo esc_attr__('Facebofacebook messengerimg','handily'); ?>">
                                <span><?php echo esc_html__('Facebook Messenger','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://twitter.com/share?url='.home_url()); ?>" id="twitter" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/twitter-img.png'); ?>" alt="<?php echo esc_attr__('twitter','handily'); ?>">
                                <span><?php echo esc_html__('Twitter','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://pinterest.com/pin/create/bookmarklet/?&amp;url='.home_url()); ?>" id="pinterest" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/pinterest-pinimg.png'); ?>" alt="<?php echo esc_attr__('pinterest','handily'); ?>">
                                <span><?php echo esc_html__('Pinterest','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://wa.me/?text='.home_url()); ?>" id="whatsapp" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/whatsapp-img.png'); ?>" alt="<?php echo esc_attr__('Whatsapp','handily'); ?>">
                                <span><?php echo esc_html__('Whatsapp','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.viber.com/en/download/?text='.home_url()); ?>" id="viber" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Viber.png'); ?>" alt="<?php echo esc_attr__('Viber','handily'); ?>">
                                <span><?php echo esc_html__('Viber','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://accounts.snapchat.com/accounts/login?client_id=geo'); ?>" id="snapchat" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/social-snapchat.png'); ?>" alt="<?php echo esc_attr__('social-snapchat','handily'); ?>">
                                <span><?php echo esc_html__('Snapchat','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.linkedin.com/shareArticle?mini=true&amp;url='.home_url()); ?>" id="linkedin" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/linkedin-img.png'); ?>" alt="<?php echo esc_attr__('linkedin','handily'); ?>">
                                <span><?php echo esc_html__('Linkedin','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://reddit.com/submit?url='.home_url()); ?>" id="reddit" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/reddit-img.png'); ?>" alt="<?php echo esc_attr__('reddit','handily'); ?>">
                                <span><?php echo esc_html__('Reddit','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.tumblr.com/widgets/share/tool?canonicalUrl='.home_url()); ?>" id="tumblr" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/tumblr-img.png'); ?>" alt="<?php echo esc_attr__('tumblr','handily'); ?>">
                                <span><?php echo esc_html__('Tumblr','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.quora.com/'); ?>" id="quora" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Quora-256.png'); ?>" alt="<?php echo esc_attr__('Quora','handily'); ?>">
                                <span><?php echo esc_html__('Quora','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://nextdoor.com/'); ?>" id="nextdoor" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/nextdoor.png'); ?>" alt="<?php echo esc_attr__('nextdoor','handily'); ?>">
                                <span><?php echo esc_html__('Nextdoor','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://foursquare.com/login'); ?>" id="foursquare" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Foursquare-256.png'); ?>" alt="<?php echo esc_attr__('Foursquare','handily'); ?>">
                                <span><?php echo esc_html__('Foursquare','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://secure.meetup.com/login/'); ?>" id="meetup" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/MeetUp.png'); ?>" alt="<?php echo esc_attr__('MeetUp','handily'); ?>">
                                <span><?php echo esc_html__('Meetup','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://deliciouskebabst5.com/'); ?>" id="delicious" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/delicious-img.png'); ?>" alt="<?php echo esc_attr__('delicious','handily'); ?>">
                                <span><?php echo esc_html__('Delicious','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://digg.com/submit?phase=2&amp;url='); ?>" id="digg" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/digg-img.png'); ?>" alt="<?php echo esc_attr__('digg','handily'); ?>">
                                <span><?php echo esc_html__('Digg','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.evernote.com/clip.action?url='.home_url()); ?>" id="evernote" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Evernote.png'); ?>" alt="<?php echo esc_attr__('Evernote','handily'); ?>">
                                <span><?php echo esc_html__('Evernote','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://share.flipboard.com/bookmarklet/popout?url='.home_url()); ?>" id="flipboard" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/flipboard-img.png'); ?>" alt="<?php echo esc_attr__('flipboard','handily'); ?>">
                                <span><?php echo esc_html__('Flipboard','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://impif.com/sharer?url='.home_url()); ?>" id="impif" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/impif.png'); ?>" alt="<?php echo esc_attr__('impif','handily'); ?>">
                                <span><?php echo esc_html__('Impif','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://meneame.net/login?return=/submit?url='.home_url()); ?>" id="meneame" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/meneame-img.png'); ?>" alt="<?php echo esc_attr__('meneame','handily'); ?>">
                                <span><?php echo esc_html__('Meneame','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://vk.com/share.php?url='.home_url()); ?>" id="vvontakte" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/vk-img.png'); ?>" alt="<?php echo esc_attr__('vk','handily'); ?>">
                                <span><?php echo esc_html__('Vkontakte','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.blogger.com/blog_this.pyra?t&amp;u='.home_url()); ?>" id="blogger" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/blogger_img.png'); ?>" alt="<?php echo esc_attr__('blogger_img','handily'); ?>">
                                <span><?php echo esc_html__('Blogger','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('mailto:?body='.home_url()); ?>" id="email" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/email-img.png'); ?>" alt="<?php echo esc_attr__('email','handily'); ?>">
                                <span><?php echo esc_html__('Email','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.xing.com/app/user?op=share&amp;url='.home_url()); ?>" id="xing" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/xing-img.png'); ?>" alt="<?php echo esc_attr__('xing-img','handily'); ?>">
                                <span><?php echo esc_html__('Xing','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://connect.mail.ru/share?share_url='.home_url()); ?>" id="mailru" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/mail-ruimg.png'); ?>" alt="<?php echo esc_attr__('mail-ruimg','handily'); ?>">
                                <span><?php echo esc_html__('Mail Ru','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.livejournal.com/update.bml?event='.home_url()); ?>" id="livejournal" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/livejournal-img.png'); ?>" alt="<?php echo esc_attr__('livejournal','handily'); ?>">
                                <span><?php echo esc_html__('Livejournal','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://myspace.com/post?l=3&amp;u='.home_url()); ?>" id="myspace" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/myspace.png'); ?>" alt="<?php echo esc_attr__('myspace','handily'); ?>">
                                <span><?php echo esc_html__('MySpace','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://buffer.com/add?url='.home_url()); ?>" id="buffer" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/buffer_img.png'); ?>" alt="<?php echo esc_attr__('buffer','handily'); ?>">
                                <span><?php echo esc_html__('Buffer','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.douban.com/share/service?url='.home_url()); ?>" id="douban" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/douban-img.png'); ?>" alt="<?php echo esc_attr__('douban','handily'); ?>">
                                <span><?php echo esc_html__('Douban','handily'); ?></span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="<?php echo esc_url('http://b.hatena.ne.jp/bookmarklet?url='.home_url()); ?>" id="hatena" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/hatena.png'); ?>" alt="<?php echo esc_attr__('hatena','handily'); ?>">
                                <span><?php echo esc_html__('Hatena','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.google.com/bookmarks/mark?op=edit&amp;bkmk='.home_url()); ?>" id="googlebookmarks" target="_blank"> 
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/bookmarks_img.png'); ?>" alt="<?php echo esc_attr__('bookmarks_img','handily'); ?>">
                                <span><?php echo esc_html__('Google Bookmarks','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=&su=Your+Subject+here&body='.home_url()); ?>" id="gmail" target="_blank"> 
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/gmail-img.png'); ?>" alt="<?php echo esc_attr__('gmail','handily'); ?>">
                                <span><?php echo esc_html__('Gmail','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://news.ycombinator.com/submitlink?u='.home_url()); ?>" id="hackernews" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/hackernews-img.png'); ?>" alt="<?php echo esc_attr__('hackernews','handily'); ?>">
                                <span><?php echo esc_html__('HackerNews','handily'); ?></span>
                            </a> 
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.instapaper.com/edit?url='.home_url()); ?>" id="instapaper" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/instapaper-img.png'); ?>" alt="<?php echo esc_attr__('instapaper','handily'); ?>">
                                <span><?php echo esc_html__('Instapaper','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://lineit.line.me/share/ui?url='.home_url()); ?>" id="line" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/line-img.png'); ?>" alt="<?php echo esc_attr__('line','handily'); ?>">
                                <span><?php echo esc_html__('Line','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://getpocket.com/edit?url='.home_url()); ?>" id="pocket" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/pocketimg.png'); ?>" alt="<?php echo esc_attr__('pocketimg','handily'); ?>">
                                <span><?php echo esc_html__('Pocket','handily'); ?></span>
                            </a>
                        </li>
                    
                        <li>
                            <a href="<?php echo esc_url('https://share.diasporafoundation.org/?title=Onboarding%20CMP%20-%20ShareThis&amp;url='.home_url()); ?>" id="diaspora" target="_blank"> 
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/diaspora-img.png'); ?>" alt="<?php echo esc_attr__('diaspora','handily'); ?>">
                                <span><?php echo esc_html__('Diaspora','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://surfingbird.ru/share?url='.home_url()); ?>" id="surfingbird" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/surfingbird-img.png'); ?>" alt="<?php echo esc_attr__('surfingbird','handily'); ?>">
                                <span><?php echo esc_html__('Surfingbird','handily'); ?></span>
                            </a> 
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://refind.com/?url='.home_url()); ?>" id="refind" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/refind-img.png'); ?>" alt="<?php echo esc_attr__('refind','handily'); ?>">
                                <span><?php echo esc_html__('Refind','handily'); ?></span>
                            </a> 
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://web.skype.com/share?url='.home_url()); ?>" id="skype" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/skype-img.png'); ?>" alt="<?php echo esc_attr__('skype','handily'); ?>">
                                <span><?php echo esc_html__('Skype','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://telegram.me/share/url?url='.home_url()); ?>" id="telegram" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/telegram-img.png'); ?>" alt="<?php echo esc_attr__('telegram','handily'); ?>">
                                <span><?php echo esc_html__('Telegram','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://wordpress.com/log-in?redirect_to='.home_url()); ?>" id="wordpress" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/wordpress-img.png'); ?>" alt="<?php echo esc_attr__('wordpress','handily'); ?>">
                                <span><?php echo esc_html__('WordPress','handily'); ?></span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="<?php echo esc_url('http://compose.mail.yahoo.com/?body='.home_url()); ?>" id="yahoomail" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/yahoomail-img.png'); ?>" alt="<?php echo esc_attr__('yahoomail','handily'); ?>">
                                <span><?php echo esc_html__('Yahoo Mail','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://mixi.jp/?url='.home_url()); ?>" id="mixi" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/mixi.png'); ?>" alt="<?php echo esc_attr__('mixi','handily'); ?>">
                                <span><?php echo esc_html__('Mixi','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.amazon.com/gp/wishlist/static-add?u='.home_url()); ?>" id="amazon" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Amazon-512.png'); ?>" alt="<?php echo esc_attr__('Amazon','handily'); ?>">
                                <span><?php echo esc_html__('Amazon','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.newsvine.com/_tools/seed&amp;save?u='.home_url()); ?>" id="newsvine" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Newsvine.png'); ?>" alt="<?php echo esc_attr__('Newsvine','handily'); ?>">
                                <span><?php echo esc_html__('Newsvine','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://app.clubhouse.io/login?url='.home_url()); ?>" id="clubhouse" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/clubhouse.png'); ?>" alt="<?php echo esc_attr__('clubhouse','handily'); ?>">
                                <span><?php echo esc_html__('Clubhouse','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.viadeo.com/shareit/share/?url='.home_url()); ?>" id="viadeo" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/viadeo-512.png'); ?>" alt="<?php echo esc_attr__('Facebook','handily'); ?>">
                                <span><?php echo esc_html__('Viadeo','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://story.kakao.com/share?url='.home_url()); ?>" id="kakao" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/kakao.png'); ?>" alt="<?php echo esc_attr__('kakao','handily'); ?>">
                                <span><?php echo esc_html__('Kakao','handily'); ?></span>
                            </a>
                        </li>
                    
                        <li>
                            <a href="<?php echo esc_url('https://www.wykop.pl/remotelink/?url='.home_url()); ?>" id="wykop" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/logo-wykop-vector.png'); ?>" alt="<?php echo esc_attr__('logo-wykop-vector','handily'); ?>">
                                <span><?php echo esc_html__('Wykop','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://secure.tagged.com/?url='.home_url()); ?>" id="tagged" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Tagged-512.png'); ?>" alt="<?php echo esc_attr__('Tagged','handily'); ?>">
                                <span><?php echo esc_html__('Tagged','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://badoo.com/?url='.home_url()); ?>" id="badoo" target="_blank">
                            <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Badoo-512.png'); ?>" alt="<?php echo esc_attr__('Badoo','handily'); ?>">
                            <span><?php echo esc_html__('Badoo','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.skyrock.com/?url='.home_url()); ?>" id="skyrock" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Skyrock.png'); ?>" alt="<?php echo esc_attr__('Skyrock','handily'); ?>">
                                <span><?php echo esc_html__('Skyrock','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.yummly.com/urb/verify?url='.home_url()); ?>" id="yummly" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Yummly.png'); ?>" alt="<?php echo esc_attr__('Yummly','handily'); ?>">
                                <span><?php echo esc_html__('Yummly','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.cellufun.com/games.asp?url='.home_url()); ?>" id="cellufun" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/cellufun.png'); ?>" alt="<?php echo esc_attr__('cellufun','handily'); ?>">
                                <span><?php echo esc_html__('Cellufun','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.wattpad.com/?url='.home_url()); ?>" id="wattpad" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/wattpad.png'); ?>" alt="<?php echo esc_attr__('wattpad','handily'); ?>">
                                <span><?php echo esc_html__('Wattpad','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.crunchyroll.com/?url='.home_url()); ?>" id="crunchyroll" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/crunchyroll.png'); ?>" alt="<?php echo esc_attr__('crunchyroll','handily'); ?>">
                                <span><?php echo esc_html__('Crunchyroll','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.caringbridge.org/?url='.home_url()); ?>" id="caringBridge" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/caring-bridge.png'); ?>" alt="<?php echo esc_attr__('caring-bridge','handily'); ?>">
                                <span><?php echo esc_html__('CaringBridge','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://steemit.com/?url='.home_url()); ?>" id="steemit" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/steemit.png'); ?>" alt="<?php echo esc_attr__('steemit','handily'); ?>">
                                <span><?php echo esc_html__('Steemit','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.caffeine.tv/?url='.home_url()); ?>" id="caffeine" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/caffeine.png'); ?>" alt="<?php echo esc_attr__('caffeine','handily'); ?>">
                                <span><?php echo esc_html__('Caffeine','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://houseparty.com/?url='.home_url()); ?>" id="houseParty" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/houseparty.png'); ?>" alt="<?php echo esc_attr__('houseparty','handily'); ?>">
                                <span><?php echo esc_html__('HouseParty','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://valence.community/?url='.home_url()); ?>" id="valence" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/valence.png'); ?>" alt="<?php echo esc_attr__('valence','handily'); ?>">
                                <span><?php echo esc_html__('Valence','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.pop-base.com/?url='.home_url()); ?>" id="popbase" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/pop_base.png'); ?>" alt="<?php echo esc_attr__('pop_base','handily'); ?>">
                                <span><?php echo esc_html__('PopBase','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://yubo.live/en?url='.home_url()); ?>" id="yubo" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/yubo.png'); ?>" alt="<?php echo esc_attr__('yubo','handily'); ?>">
                                <span><?php echo esc_html__('Yubo','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://elpha.com/?url='.home_url()); ?>" id="elpha" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/elpha.png'); ?>" alt="<?php echo esc_attr__('elpha','handily'); ?>">
                                <span><?php echo esc_html__('Elpha','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.triller.co/?url='.home_url()); ?>" id="triller" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/triller.png'); ?>" alt="<?php echo esc_attr__('triller','handily'); ?>">
                                <span><?php echo esc_html__('Triller','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://cafemom.com/'); ?>" id="cafeMom" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/cafemom.png'); ?>" alt="<?php echo esc_attr__('cafemom','handily'); ?>">
                                <span><?php echo esc_html__('CafeMom','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://discord.com/?url='.home_url()); ?>" id="discord" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/discord.png'); ?>" alt="<?php echo esc_attr__('discord','handily'); ?>">
                                <span><?php echo esc_html__('Discord','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://medium.com/'); ?>" id="medium" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Medium.png'); ?>" alt="<?php echo esc_attr__('Medium','handily'); ?>">
                                <span><?php echo esc_html__('Medium','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.twitch.tv/?url='.home_url()); ?>" id="twitch" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/twitch_PNG28.png'); ?>" alt="<?php echo esc_attr__('twitch','handily'); ?>">
                                <span><?php echo esc_html__('Twitch','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.goodreads.com/?url='.home_url()); ?>" id="goodreads" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/goodreads-round-light-1-512.png'); ?>" alt="<?php echo esc_attr__('goodreads-round-light','handily'); ?>">
                                <span><?php echo esc_html__('Goodreads','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.peanut-app.io/?url='.home_url()); ?>" id="peanut" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Peanut.png'); ?>" alt="<?php echo esc_attr__('Peanut','handily'); ?>">
                                <span><?php echo esc_html__('Peanut','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.meetme.com/?url='.home_url()); ?>" id="meetme" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/meetme.png'); ?>" alt="<?php echo esc_attr__('meetme','handily'); ?>">
                                <span><?php echo esc_html__('MeetMe','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.buzznet.com/?url='.home_url()); ?>" id="buzznet" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Buzznet.png'); ?>" alt="<?php echo esc_attr__('Buzznet','handily'); ?>">
                                <span><?php echo esc_html__('Buzznet','handily'); ?></span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="<?php echo esc_url('https://www.funnyordie.com/?url='.home_url()); ?>" id="funnyordie" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/funnyordie.png'); ?>" alt="<?php echo esc_attr__('funnyordie','handily'); ?>">
                                <span><?php echo esc_html__('Funny or Die','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.myheritage.com/?url='.home_url()); ?>" id="myheritage" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/MyHeritage.png'); ?>" alt="<?php echo esc_attr__('MyHeritage','handily'); ?>">
                                <span><?php echo esc_html__('MyHeritage','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.classmates.com/?url='.home_url()); ?>" id="classmates" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Classmates.png'); ?>" alt="<?php echo esc_attr__('Classmates','handily'); ?>">
                                <span><?php echo esc_html__('Classmates','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://weheartit.com/?url='.home_url()); ?>" id="weheartit" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/weloveit.png'); ?>" alt="<?php echo esc_attr__('weloveit','handily'); ?>">
                                <span><?php echo esc_html__('We Heart It','handily'); ?></span>
                            </a>
                        </li>
                    
                        <li>
                            <a href="<?php echo esc_url('https://www.care2.com/?url='.home_url()); ?>" id="care2" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/care2.png'); ?>" alt="<?php echo esc_attr__('care2','handily'); ?>">
                                <span><?php echo esc_html__('Care2','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.wayn.com/?url='.home_url()); ?>" id="wayn" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/wayn.png'); ?>" alt="<?php echo esc_attr__('wayn','handily'); ?>">
                                <span><?php echo esc_html__('Wayn','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.flixster.com/?url='.home_url()); ?>" id="flixster" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/Flixster.png'); ?>" alt="<?php echo esc_attr__('Flixster','handily'); ?>">
                                <span><?php echo esc_html__('Flixster','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.reverbnation.com/?url='.home_url()); ?>" id="reverbnation" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/ReverbNation.png'); ?>" alt="<?php echo esc_attr__('ReverbNation','handily'); ?>">
                                <span><?php echo esc_html__('ReverbNation','handily'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.snapfish.com/home?url='.home_url()); ?>" id="snapfish" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/handily/assets/images/social/snapfish.png'); ?>" alt="<?php echo esc_attr__('snapfish','handily'); ?>">
                                <span><?php echo esc_html__('Snapfish','handily'); ?></span>
                            </a>
                        </li>
                        </ul>
                    </div>
                </div>
            </div>
         </div>
    </div>
</div>