<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://codecanyon.net/user/kamleshyadav
 * @since      1.0.0
 *
 * @package    Handily
 * @subpackage Handily/admin/partials
 */
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="hl-main-wraper">
    <div class="container">
      <div class="row">
         <div class="col-md-12">
              <div class="hl-welcome-wrap">
                <h1><?php echo esc_html__('Welcome To','handily'); ?><span><?php echo esc_html__(' Handily','handily'); ?></span></h1>
                </div> 
           </div>
       </div>
      
     <div class="hl-card-body">
       <div class="row">
        <?php 
        $handily_startbooking = get_option('handily_connection_details');
        if(!empty($handily_startbooking)):
        ?> 
        <div class="col-lg-4 offset-lg-4">
            <?php 
            switch ($handily_startbooking):
              case 'hotelbooking':
              ?> 
              <div class="hl-category-box hl-purple-bg">
                <img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/hotel.png'); ?>" alt="<?php echo esc_attr__('Hotel icon','handily'); ?>">
                <h3><?php echo esc_html__('Hotel booking','handily'); ?></h3>
                <a class="hl-btn hl_disconnectbookings" data-startbookings="<?php echo esc_attr__('hotelbooking','handily'); ?>"><?php echo esc_html__('Disconnect','handily'); ?></a>
              </div>  
              <?php
              break;
              case 'cafebooking':
              ?>
              <div class="hl-category-box hl-blue-bg">
                <img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/coffee.png'); ?>" alt="<?php echo esc_attr__('cafe icon','handily'); ?>">
                <h3><?php echo esc_html__('Cafe booking','handily'); ?></h3>
                <a class="hl-btn hl_disconnectbookings" data-startbookings="<?php echo esc_attr__('cafebooking','handily'); ?>"><?php echo esc_html__('Disconnect','handily'); ?></a>
              </div> 
              <?php
              break;
              case 'appointmentbooking':
              ?>
              <div class="hl-category-box hl-orange-bg">
                 <img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/booking.png'); ?>" alt="<?php echo esc_attr__('Appointment icon','handily'); ?>">
                 <h3><?php echo esc_html__('Appointment booking','handily'); ?></h3>
                 <a class="hl-btn hl_disconnectbookings" data-startbookings="<?php echo esc_attr__('appointmentbooking','handily'); ?>"><?php echo esc_html__('Disconnect','handily'); ?></a> 
              </div>  
              <?php
              break;
            endswitch;
            ?>
        </div>
        <?php
         else:
        ?>
          <div class="col-lg-4 col-md-6">
            <div class="hl-category-box hl-purple-bg">
            <img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/hotel.png'); ?>" alt="<?php echo esc_attr__('Hotel icon','handily'); ?>">
            <h3><?php echo esc_html__('Hotel booking','handily'); ?></h3>
            <a class="hl-btn hl_startbookings" data-startbookings="<?php echo esc_attr__('hotelbooking','handily'); ?>"><?php echo esc_html__('Start','handily'); ?></a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
              <div class="hl-category-box hl-blue-bg">
              <img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/coffee.png'); ?>" alt="<?php echo esc_attr__('cafe icon','handily'); ?>">
              <h3><?php echo esc_html__('Cafe booking','handily'); ?></h3>
              <a class="hl-btn hl_startbookings" data-startbookings="<?php echo esc_attr__('cafebooking','handily'); ?>"><?php echo esc_html__('Start','handily'); ?></a>
              </div> 
          </div>
          <div class="col-lg-4 col-md-6">
              <div class="hl-category-box hl-orange-bg">
                <img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/booking.png'); ?>" alt="<?php echo esc_attr__('Appointment icon','handily'); ?>">
                <h3><?php echo esc_html__('Appointment booking','handily'); ?></h3>
                <a class="hl-btn hl_startbookings" data-startbookings="<?php echo esc_attr__('appointmentbooking','handily'); ?>"><?php echo esc_html__('Start','handily'); ?></a> 
              </div>  
          </div> 
          <?php
          endif;
          ?>
          </div>
       </div>
      <!-- Loader Section Start  -->
      <div class="hl-preloader">
        <div class="hl-preloader-box">
        <svg xmlns="http://www.w3.org/2000/svg" width="200px" height="200px" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
              <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="0s"></animate>
              <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="0s"></animate>
            </circle><circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
              <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
              <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
            </circle>
        </svg>
        </div>
      </div>
      <!-- Loader Section End -->
    </div> 
</div>