<?php 
require_once( dirname(__FILE__) . '/../../../../wp-load.php' ); // WP environment
require_once( dirname(__FILE__) . '/striplibary/init.php' ); // I placed the directory with Stripe PHP library in the theme folder
if(isset($_POST['stripeToken'])){
    /* we specified this parameter as a hidden field */ 
	require_once plugin_dir_path( dirname( __FILE__ ) ). 'Twilio/autoload.php';
    $stripe_secretkey = get_option('stripe_cafe_secret_key');
    $booking_price = get_option('cafe_confirmation_charge');
    if(empty($_POST['new_price'])){
        $booking_price = $_POST['new_price'];
    }
    $currency =  get_option('curreny_val'); 
    $first_name = '';
    if(isset($_POST['strip_cust_name'])):
    $first_name = $_POST['strip_cust_name'];
    endif;
    $eamil = '';
    if(isset($_POST['eamil'])):
    $eamil = $_POST['eamil'];
    endif;
    $contact_number = '';
    if(isset($_POST['contact_number'])):
    $contact_number = $_POST['contact_number'];
    endif;
    $event_type = '';
    if(isset($_POST['event_type'])):
    $event_type = $_POST['event_type'];
    endif;
    $num_of_guests = '';
    if(isset($_POST['num_of_guests'])):
    $num_of_guests = $_POST['num_of_guests'];
    endif;
    $strip_cust_message = '';
    if(isset($_POST['strip_cust_message'])):
    $strip_cust_message = $_POST['strip_cust_message'];
    endif;
    $strip_booking_date = '';
    if(isset($_POST['strip_booking_date'])):
    $strip_booking_date = $_POST['strip_booking_date'];
    endif;
    $strip_booking_time = '';
    if(isset($_POST['strip_booking_time'])):
    $strip_booking_time = $_POST['strip_booking_time'];
    endif;

	\Stripe\Stripe::setApiKey($stripe_secretkey);
    /* if your plugin price looks like 9.59, then you need to *100 it */
	$price = $booking_price*100;
	try {
	    if(!isset($_POST['stripeToken']) )
		  throw new Exception('The Stripe Token is not correct');
		/* make a charge */
		$rdata = \Stripe\Charge::create( array( 'amount' => $price, 'currency' => $currency, 'source' => $_POST['stripeToken'], 'description' => 'User Name' .$first_name.') User EMail: ' . $_POST['stripeEmail'] ) );
        if($rdata): 
        global $wpdb; 
        $tbl_pay = $wpdb->prefix. 'cafe_table_booked';
        $current_user = wp_get_current_user();
        $tranx_amount = $price/100;;
        $tranx_id = $rdata->balance_transaction;
        $tranx_status = $rdata->status;
        $user_id = '';
        $bc_table_id = '';
        $wpdb->insert( 
            $tbl_pay, 
            array( 
                'bc_user_id' => $user_id, 
                'bc_table_id' => $bc_table_id, 
                'bc_booking_date' => $strip_booking_date, 
                'bc_booking_time' => $strip_booking_time,  
                'bc_txnid' => $tranx_id, 
                'bc_payment_amount' => $tranx_amount, 
                'bc_payment_status' => $tranx_status, 
                'bc_timestamp' => date('Y-m-d H:i:s'), 
                'bc_customer_details' => json_encode($_POST), 
                'bc_payment_getway' => esc_attr__('Strip','handily'), 
                )
        ); 
    if($wpdb->insert_id){
        $string_a = array();
				$string_a[0] = '[{payment_id}]';
				$string_a[1] = '[{name}]';
				$string_a[2] = '[{eamil}]';
				$string_a[3] = '[{phone}]';
				$string_a[4] = '[{event}]';
				$string_a[5] = '[{guests}]';
				$string_a[6] = '[{message}]';
				$string_a[7] = '[{booking_date}]';
				$string_a[8] = '[{booking_time}]';
				$string_a[9] = '[{amount}]';
				$string_a[10] = '[{total_price}]';
				$string_a[11] = '[{tax_name}]';
				$string_a[12] = '[{text_percent}]';
				
				$string_b = array();				
				$string_b[0] = $tranx_id;
				$string_b[1] = $first_name;
				$string_b[2] = $eamil;
				$string_b[3] = $contact_number;
				$string_b[4] = $event_type;
				$string_b[5] = $num_of_guests;
				$string_b[6] = $strip_cust_message;
				$string_b[7] = $strip_booking_date;
				$string_b[8] = $strip_booking_time;
				$string_b[9] = $tranx_amount;
				$string_b[10] = $_POST['new_price'];
				$string_b[11] = $_POST['tax_name_n'];
				$string_b[12] = $_POST['text_percent_n'];				
				
				$mail_msg = get_option('cafe_email_content');
				$email_h = get_option('cafe_email_h');
				$email_sub = get_option('cafe_email_sub');
				
				$site = get_bloginfo( 'name' );
				
				if(!empty($mail_msg)){
				        $html = preg_replace($string_a, $string_b, $mail_msg);
				} else{
				       $html = '<div class="mail_template">
				            <h1>'. $email_h .'</h1>
				            <h4>'. esc_html__('Welcome to', 'Handly'). ' '. $site .'</h4>
				            <h6>'. esc_html__('Invocie #Order', 'Handly'). ' ' . $tranx_id. '<h6>
				            <p>'. esc_html__('Hurray!! The table has been booked for the', 'Handly'). ' '. $event_type .' '. esc_html__('on dated', 'Handly'). ' ' . $strip_booking_date . ' '. esc_html__('at', 'Handly'). ' ' . $strip_booking_time . ''.esc_html__('.', 'Handly') .'</p>
				            <p>'. esc_html__('Lets have fun at', 'Handly').' '. $site .'</p>
				        </div>';
				}
				
    		    $web_url =$html;
				$header = '';
                $emailmessage = $email_sub;  
                $customer_email = $eamil;
                $admin_email = get_option('admin_email');
                $headers = array('Content-Type: text/html; charset=UTF-8',$header); 
                $multiple_emails = array(
                    $admin_email, 
                    $customer_email,
                );
                wp_mail($multiple_emails, $emailmessage, $web_url, $headers);
				
						
				$sid = get_option('cafe_acsid');
				if(!empty($sid)){
				$token  = get_option('cafe_auth_token');
				$virfynumber  = get_option('cafe_ac_phone');
				
				$sms = esc_html__('Thanks for making the table booking at', 'Handly').' '. $site .' '. esc_html__('Your table on dated', 'Handly') .' '. $strip_booking_date .' '. esc_html__(' has been booked successfully.', 'Handly');
        
				$twilio = new Twilio\Rest\Client($sid, $token);
				$message = $twilio->messages 
                  ->create("+91".$contact_number, // to 
                           array(  
                               "messagingServiceSid" => get_option('cafe_ac_mssid'),      
                               "body" => $sms,
                           ) 
                  ); 
				$message->sid;
				}
		$success_url = get_option('stripe_cafe_success_url').'/?invoice='.base64_encode($wpdb->insert_id);
		wp_safe_redirect($success_url);   
    }else{ 
       echo esc_html__('Something Went Wrong!','handily');
       $cancel_url = get_option('stripe_cafe_cancel_url');
       wp_safe_redirect($cancel_url);
    }  
endif; 
} catch (Exception $e) {
    /**
     * if something goes wrong
     */ 
    echo $e->getMessage();
} 

}else{
	esc_html_e('The Stripe Token is not correct','handily');
}