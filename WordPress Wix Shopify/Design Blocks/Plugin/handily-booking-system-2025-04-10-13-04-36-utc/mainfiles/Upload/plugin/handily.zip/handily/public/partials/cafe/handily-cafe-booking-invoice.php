<div class="hl-spacer-top hl-spacer-bottom hl-booking-invoice">
    <div class="container">
        <div class="row" id="hl-booking-invoice">
            <div class="col-md-12">
                <div class="hl-payment-handily">
                    <div class="hl-payment-header">
                        <div class="hl-payment-site-name">
                        <?php 
                        $booking_invoice_heading = get_option('cafe_booking_invoice_heading');
                        if(!empty($booking_invoice_heading)):
                        ?><h2><?php echo esc_html($booking_invoice_heading); ?></h2>
                        <?php endif; ?> 
                        </div>
                    </div>
                    <ul>
                    <?php 
                    if(isset($_GET['invoice'])):
                    global $wpdb;
                    $bc_id = base64_decode($_GET['invoice']);
                    $pmt_tbl = $wpdb->prefix . 'cafe_table_booked';
                    $booking_query = $wpdb->get_results("SELECT * FROM $pmt_tbl WHERE bc_id in($bc_id)");  
                    if($booking_query) {  
                        foreach ($booking_query as $booking) {
                            $customer_details = json_decode($booking->bc_customer_details);
                            $customer_name = '';
                            if(!empty($customer_details->strip_cust_name)):
                            $customer_name = $customer_details->strip_cust_name;
                            endif;
                            $eamil = '';
                            if(!empty($customer_details->eamil)):
                            $eamil = $customer_details->eamil;
                            endif;
                            $contact_number = '';
                            if(!empty($customer_details->contact_number)):
                            $contact_number = $customer_details->contact_number;
                            endif;
                            $event_type = '';
                            if(!empty($customer_details->event_type)):
                            $event_type = $customer_details->event_type;
                            endif; 
                            if(!empty($customer_name)):
                            ?>
                            <li><span><?php esc_html_e('Name:','handily'); ?></span><?php echo esc_html($customer_name); ?></li>
                            <?php 
                            endif;  
                            if(!empty($contact_number)):
                            ?>
                            <li><span><?php esc_html_e('Contact Number:','handily'); ?></span><?php echo esc_html($contact_number); ?></li>
                            <?php
                            endif;
                            if(!empty($eamil)):
                            ?>
                            <li><span><?php esc_html_e('Eamil Address:','handily'); ?></span><?php echo esc_html($eamil); ?></li>
                            <?php 
                            endif;
                            if(!empty($event_type)):
                            ?>
                            <li><span><?php esc_html_e('Event Type:','handily'); ?></span><?php echo esc_html($event_type); ?></li>
                            <?php 
                            endif;
                            }
                            $price_currency = get_option('stripe_cafe_currency_val');
                            if(!empty($price_currency) && !empty($booking->bc_payment_amount)):
                            ?>
                            <li><span><?php esc_html_e('Pay Amount:','handily'); ?></span>
                            <?php echo esc_html($price_currency).''.esc_html($booking->bc_payment_amount); ?></li>
                            <?php 
                            endif;
                            if(!empty($booking->bc_txnid)):
                            ?>
                            <li><span><?php esc_html_e('Transaction ID:','handily'); ?></span>
                            <?php echo esc_html($booking->bc_txnid); ?></li>
                            <?php  
                            endif;
                            if(!empty($booking->bc_payment_status)):
                            ?>
                            <li><span><?php esc_html_e('Payment Status:','handily'); ?></span><?php echo esc_html($booking->bc_payment_status); ?></li>
                            <?php 
                            endif;
                        }
                    ?>
                    </ul>
                   </div>
                    
                    <?php endif; ?>
                </div> 
                
            </div>
            <a href="javascript:void(0)" id="hl_print_button" class="hl-btn"><?php echo esc_html__('Print','handily'); ?></a>
        </div>
        
    </div>
    