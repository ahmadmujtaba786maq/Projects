<?php 
 /**
* Shortode
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} 
// Wp backey Shortcode Map
add_action( 'vc_before_init', 'handily_room_view' );
function handily_room_view(){
    vc_map( array(
		"name" => __( "Room View", "handily" ),
		"base" => "handily_room",
		"category" => __("Handily","handily"), 
		"params" => array( 
		        
		),
	));
}