<?php
/**
 * Handily Color Option 
 */
$colors_codes_primary = get_option('primary_color');
if(empty($colors_codes_primary)){
  $colors_codes_primary = esc_html__('#ff9092','handily');
}
$gradient_first_color = get_option('gc_color');
if(empty($gradient_first_color)){
    $gradient_first_color = esc_html__('#ff9092','handily');
  }
$gradient_second_color = get_option('gcc_color');
if(empty($gradient_second_color)){
    $gradient_second_color = esc_html__('#ff9092','handily');
}
?> 
<style>
:root {
    --primary : <?php echo esc_html($colors_codes_primary);?> !important;
    --gradient_first_color: <?php echo esc_html($gradient_first_color);?> !important;
    --gradient_second_color: <?php echo esc_html($gradient_second_color);?> !important;
}
</style>
