<div class="hl-main-wraper">
   <div class="container-fluid">
        <div class="hl-card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hl-hotal-tabs">
                        <ul>
                            <li>
                             <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_rooms')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/bed.png'); ?>" alt="<?php esc_attr_e('Rooms icon ','handily'); ?>"><?php echo esc_html__('Rooms','handily'); ?></a>
                            </li>
                            <li>
                             <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_booking')); ?>" class="handily_active"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/calendar.png'); ?>" alt="<?php esc_attr_e('Bookings icon','handily'); ?>"><?php echo esc_html__('Bookings','handily'); ?></a>
                            </li>
                            <li>
                              <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_payment')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/credit-card.png'); ?>" alt="<?php esc_attr_e('Payment icon','handily'); ?>"><?php echo esc_html__('Payment Settings','handily'); ?></a>
                            </li>
                            <li>
                              <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_form')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/form.png'); ?>" alt="<?php esc_attr_e('Form icon','handily'); ?>"><?php echo esc_html__('Form Settings','handily'); ?></a>
                            </li>  
                        </ul>
                    </div>
                </div>
            </div>
            <form method="get" class="user-form-listing">
	            <input type="hidden" name="s" value="<?php echo esc_attr__('n','handily'); ?>" />
                <input type="hidden" name="page" value="<?php echo wp_kses($_REQUEST['page'],true); ?>" />
				<a href="javascript:void(0);" class="hl-btn" id="xlsexport"><?php echo esc_html__('Xls Export','handily'); ?></a>
				<a href="javascript:void(0);" class="hl-btn" id="csvexport"><?php echo esc_html__('CSV Export','handily'); ?></a>
            <?php 
            echo "<h1 class='hl-heading-title'>".esc_html__('Booking List','handily')."</h1>";
            require dirname( __FILE__ ) . '/handily-data-list.php';
            $list_table = new handily_booking_Table(); 
            $list_table->prepare_items();
            $list_table->search_box('Search', 'search');
            ?>
            <div class="hl-table-wrapper">
            <?php
             $list_table->display();
            ?>
           </div>
          </form>
        </div>
     </div>
</div>