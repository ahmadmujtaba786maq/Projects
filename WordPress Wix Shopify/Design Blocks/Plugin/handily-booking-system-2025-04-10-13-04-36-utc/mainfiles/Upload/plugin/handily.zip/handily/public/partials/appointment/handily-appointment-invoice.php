<div class="hl-spacer-top hl-spacer-bottom hl-booking-invoice">
    <div class="container">
        <div class="row" id="hl-booking-invoice">
            <div class="col-md-12">
                <div class="hl-payment-handily">
                    <div class="hl-payment-header">
                        <div class="hl-payment-site-name">
                            <?php 
                            $booking_invoice_heading = get_option('appointment_booking_invoice_heading');
                            if(!empty($booking_invoice_heading)):
                            ?><h2><?php echo esc_html($booking_invoice_heading); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                    <ul>
                    <?php 
                    if(isset($_GET['invoice'])):
                    global $wpdb;
                    $b_id = base64_decode($_GET['invoice']);
                    $pmt_tbl = $wpdb->prefix . 'appointment_schedule_booked';
                    $booking_query = $wpdb->get_results("SELECT * FROM $pmt_tbl WHERE asb_id in($b_id)"); 
                    if($booking_query) {  
                        foreach ($booking_query as $booking) {
                            $customer_details = '';
                            if(!empty($booking->asb_customer_details)):
                              $customer_details = json_decode($booking->asb_customer_details);
                            endif;
                            $cust_name = '';
                            if(!empty($customer_details->strip_cust_name)):
                            $cust_name = $customer_details->strip_cust_name;
                            endif;
                            $eamil = '';
                            if(!empty($customer_details->eamil)):
                            $eamil = $customer_details->eamil;
                            endif;
                            $contact_number = '';
                            if(!empty($customer_details->contact_number)):
                            $contact_number = $customer_details->contact_number;
                            endif;
                            $booking_date = '';
                            if(!empty($customer_details->strip_booking_date)):
                              $booking_date = $customer_details->strip_booking_date;
                            endif;
                            $booking_time = '';
                            if(!empty($customer_details->strip_booking_time)):
                              $booking_time = $customer_details->strip_booking_time;
                            endif;
                            $cust_message = '';
                            if(!empty($customer_details->strip_cust_message)):
                              $cust_message = $customer_details->strip_cust_message;
                            endif; 
                            if(!empty($cust_name)):
                            ?>
                            <li><span><?php esc_html_e('Name:','handily'); ?></span><?php echo esc_html($cust_name); ?></li>
                            <?php 
                            endif; 
                            if(!empty($eamil)):
                            ?>
                            <li><span><?php esc_html_e('Eamil Address:','handily'); ?></span><?php echo esc_html($eamil); ?></li>
                            <?php 
                            endif;
                            if(!empty($contact_number)):
                            ?>
                            <li><span><?php esc_html_e('Contact Number:','handily'); ?></span><?php echo esc_html($contact_number); ?></li>
                            <?php
                            endif;
                            if(!empty($booking_date)):
                            ?>
                            <li><span><?php esc_html_e('Booking Date:','handily'); ?></span><?php echo esc_html($booking_date); ?></li>
                            <?php
                            endif;
                            if(!empty($booking_time)):
                            ?>
                            <li><span><?php esc_html_e('Booking Time:','handily'); ?></span><?php echo esc_html($booking_time); ?></li>
                            <?php 
                            endif;
                            if(!empty($cust_message)):
                            ?>
                            <li><span><?php esc_html_e('Message:','handily'); ?></span><?php echo esc_html($cust_message); ?></li> 
                            <?php 
                            endif;
                            }
                            $price_currency = get_post_meta($booking->asb_schedule_id,'appointment_currency',true);
                            if(!empty($price_currency) && !empty($booking->asb_payment_amount)):
                            ?>
                            <li><span><?php esc_html_e('Pay Amount:','handily'); ?></span>
                            <?php echo esc_html($price_currency).''.esc_html($booking->asb_payment_amount); ?></li>
                            <?php 
                            endif;
                            if(!empty($booking->asb_txnid)):
                            ?>
                            <li><span><?php esc_html_e('Transaction ID:','handily'); ?></span>
                            <?php echo esc_html($booking->asb_txnid); ?></li>
                            <?php  
                            endif;
                            if(!empty($booking->asb_payment_status)):
                            ?>
                            <li><span><?php esc_html_e('Payment Status:','handily'); ?></span><?php echo esc_html($booking->asb_payment_status); ?></li>
                            <?php 
                            endif;
                          }
                        ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div> 
        </div>
       <a href="javascript:void(0)" id="hl_print_button" class="hl-btn"><?php echo esc_html__('Print','handily'); ?></a>
   </div>
</div> 