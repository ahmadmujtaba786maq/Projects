<?php 
require_once( dirname(__FILE__) . '/../../../../wp-load.php' ); // WP environment
require_once( dirname(__FILE__) . '/striplibary/init.php' ); // I placed the directory with Stripe PHP library in the theme folder
if(isset($_POST['stripeToken'])){
    
    /* we specified this parameter as a hidden field */
	require_once plugin_dir_path( dirname( __FILE__ ) ). 'Twilio/autoload.php';
    $schedule_id = $_POST['item_id']; 
	$stripe_secretkey = get_option('stripe_appointment_secret_key');
    //$currency = get_option('app_curreny_val');
    $currency = 'USD';
    $schedule_price = get_post_meta($schedule_id,'appointment_schedule_price',true);
    if(empty($_POST['new_price'])){
        $schedule_price = $_POST['new_price'];
    }
    
    $cust_name = '';
    if(isset($_POST['strip_cust_name'])):
    $cust_name = $_POST['strip_cust_name'];
    endif;
    $eamil = '';
    if(isset($_POST['eamil'])):
    $eamil = $_POST['eamil'];
    endif;
    $contact_number = '';
    if(isset($_POST['contact_number'])):
    $contact_number = $_POST['contact_number'];
    endif;
    $cust_message = '';
    if(isset($_POST['strip_cust_message'])):
    $cust_message = $_POST['strip_cust_message'];
    endif;
    $booking_date = '';
    if(isset($_POST['strip_booking_date'])):
    $booking_date = $_POST['strip_booking_date'];
    endif; 
    $booking_time = '';
    if(isset($_POST['strip_booking_time'])):
    $booking_time = $_POST['strip_booking_time'];
    endif; 

    \Stripe\Stripe::setApiKey($stripe_secretkey);
    /* if your plugin price looks like 9.59, then you need to *100 it */
	$price = $schedule_price*100; 
	try {
	    
        if(!isset($_POST['stripeToken']) )
			throw new Exception('The Stripe Token is not correct');
		/* make a charge */
		$rdata = \Stripe\Charge::create( array( 'amount' => $price, 'currency' => $currency, 'source' => $_POST['stripeToken'], 'description' => 'User Name' .$cust_name.') User EMail: '.$_POST['stripeEmail']));
       
        if($rdata): 
            global $wpdb; 
            $tbl_pay = $wpdb->prefix. 'appointment_schedule_booked';
            $current_user = wp_get_current_user();
            $tranx_amount = $price/100;;
            $tranx_id = $rdata->balance_transaction;
            $tranx_status = $rdata->status; 
            $user_id = '';
            $wpdb->insert( 
                $tbl_pay, 
                array( 
                    'asb_user_id' => $user_id, 
                    'asb_schedule_id' => $schedule_id, 
                    'asb_schedule_date' => $booking_date, 
                    'asb_schedule_time' => $booking_time, 
                    'asb_txnid' => $tranx_id, 
                    'asb_payment_amount' => $tranx_amount, 
                    'asb_payment_status' => $tranx_status, 
                    'asb_timestamp' => date('Y-m-d H:i:s'), 
                    'asb_customer_details'=> json_encode($_POST), 
                    'asb_payment_getway' => 'Stripe', 
                   ),  
                array(
                    '%d', 
                    '%d', 
                    '%s', 
                    '%s', 
                    '%s', 
                    '%d', 
                    '%s', 
                    '%s', 
                    '%s', 
                    '%s', 
                ) 
            ); 
     
        if($wpdb->insert_id){
        $string_a = array();
				$string_a[0] = '[{payment_id}]';
				$string_a[1] = '[{name}]';
				$string_a[2] = '[{eamil}]';
				$string_a[3] = '[{phone}]';
				$string_a[4] = '[{message}]';
				$string_a[5] = '[{booking_date}]';
				$string_a[6] = '[{booking_time}]';
				$string_a[7] = '[{amount}]';
				$string_a[8] = '[{total_price}]';
				$string_a[9] = '[{tax_name}]';
				$string_a[10] = '[{text_percent}]';
				
				$string_b = array();				
				$string_b[0] = $tranx_id;
				$string_b[1] = $cust_name;
				$string_b[2] = $eamil;
				$string_b[3] = $contact_number;
				$string_b[4] = $cust_message;
				$string_b[5] = $booking_date;
				$string_b[6] = $booking_time;
				$string_b[9] = $schedule_price;
				$string_b[8] = $_POST['new_price'];
				$string_b[9] = $_POST['tax_name_n'];
				$string_b[10] = $_POST['text_percent_n'];				
				
				$mail_msg = get_option('app_email_content');
				$email_h = get_option('app_email_h');
				$email_sub = get_option('cafe_email_sub');
				
				$site = get_bloginfo( 'name' );
				
				if(!empty($mail_msg)){
				        $html = preg_replace($string_a, $string_b, $mail_msg);
				} else{
				       $html = '<div class="mail_template">
				            <h1>'. $email_h .'</h1>
				            <h4>'. esc_html__('Welcome to '. $site .' hospital.', 'Handly'). ' </h4>
				            <h6>'. esc_html__('Invocie #Order', 'Handly'). ' ' . $tranx_id. '<h6>
				            <p>'. esc_html__('Your appointment with Dr ABC has been scheduled successfully at '. $booking_time .' on dated '.$booking_date .'', 'Handly').'</p>
				            <p>'. esc_html__('The consultation charge '. $currency . ''. $schedule_price .'  including '. $_POST['tax_name_n'] .' tax.', 'Handly').' '. $site .'</p>
				        </div>';
				}
				
    		    $web_url =$html;
				$header = '';
                $emailmessage = $email_sub;  
                $customer_email = $eamil;
                $admin_email = get_option('admin_email');
                $headers = array('Content-Type: text/html; charset=UTF-8',$header); 
                $multiple_emails = array(
                    $admin_email, 
                    $customer_email,
                );
                wp_mail($multiple_emails, $emailmessage, $web_url, $headers);
				
						
				$sid = get_option('app_acsid');
				if(!empty($sid)){
				$token  = get_option('app_auth_token');
				$virfynumber  = get_option('app_ac_phone');
				
				$sms = esc_html__('Thank you for using our services. Your appointment has been scheduled successfully at '. $booking_time .' on dated '.$booking_date .'', 'Handly');
               
                if (!empty($token)) {
				$twilio = new Twilio\Rest\Client($sid, $token);
			   
				$message = $twilio->messages 
                  ->create("+91".$contact_number, // to 
                           array(  
                               "messagingServiceSid" => get_option('app_ac_mssid'),      
                               "body" => $sms,
                           ) 
                  ); 
				$message->sid;
				}
				}
				
	$success_url = get_option('stripe_appointment_success_url').'/?invoice='.base64_encode($wpdb->insert_id);
		wp_safe_redirect($success_url);  
    }else{  
        echo esc_html__('Something Went Wrong!','handily');
        $cancel_url = get_option('stripe_appointment_cancel_url');
        wp_safe_redirect($cancel_url); 
        } 
    endif; 
} catch (Exception $e) {
    /**
     * if something goes wrong
     */ 
    echo $e->getMessage();
} 

}else{
	esc_html_e('The Stripe Token is not correct','handily');
}