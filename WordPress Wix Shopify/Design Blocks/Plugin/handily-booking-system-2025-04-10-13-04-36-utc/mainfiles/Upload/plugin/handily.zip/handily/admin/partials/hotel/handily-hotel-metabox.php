<?php
/**
 * Handily Hotel Metabox 
 */
class Hotel_metabox{
    /**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
    public $prefix;
    public $page_option_meta;
	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

        $this->prefix = 'hotel_';
        
        $curreny_val = get_option('curreny_val');	
        /**
         * Hotel Room Meta Option  
         */ 
        $this->page_option_meta = array(
            'id' => 'section-page-meta',
            'title' => esc_html__('Hotel Rooms Settings','handily'),
            'page' => 'rooms',
            'context' => 'normal',
            'priority' => 'high',
            'fields' => array(
                    array(
                        'name' => esc_html__('Currency','handily'),
                        'desc' => '',
                        'id' => $this->prefix.'currency',
                        'type' => 'text',
                        'std' => $curreny_val,
                        'cls' => 'hide_row'
                       ),
                    array(
                        'name' => esc_html__('Room Price','handily'),
                        'desc' => '',
                        'id' => $this->prefix.'room_price',
                        'type' => 'text',
                        'std' => '',
                        'cls' => 'hide_row'
                       ),
                    array(
                        'name' => esc_html__('Room Capacity','handily'),
                        'desc' => '', 
                        'id' => $this->prefix.'room_capacity', 
                        'type' => 'text',
                        'std' => '',
                        'cls' => 'hide_row'
                       ),
                    array(
                        'name' => esc_html__('Change Status', 'handily'),
                        'desc' => '',
                        'id' => $this->prefix.'status',
                        'type' => 'select',
                        'options' => array('open'=>'Open','close'=>'Close')
                       ),   
                    array(
                        'name' => esc_html__('Enter More Details', 'handily'),
                        'desc' => '',
                        'id' => $this->prefix.'location_map',
                        'type' => 'textarea',
                        'std' => '',
                        'cls' => 'hide_row'
                       ),
                    array(
                        'name' => esc_html__('Upload Room Gallery Image', 'handily'),
                        'desc' => '',
                        'id' => $this->prefix.'location_map',
                        'type' => 'gallery_image',
                        'std' => '',
                        'cls' => 'hide_row'
                       ),
                    )
               );

	}
    /**
     * Hotel Room Add Meta Option
     */
    public function hotel_add_meta_boxes(){
        $page_option_meta = $this->page_option_meta;
        add_meta_box($page_option_meta['id'], $page_option_meta['title'], array($this,'hotel_show_meta_options'), $page_option_meta['page'], $page_option_meta['context'], $page_option_meta['priority']);

    }
    /**
     * Hotel Room Add Meta Option
     */
    public function hotel_show_meta_options(){
        global $post;
        $page_option_meta = $this->page_option_meta;
        $val = '';
		// Use nonce for verification
		echo '<input type="hidden" name="meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
		echo '<table class="form-table hl-room-setting-wrap">';
		foreach ($page_option_meta['fields'] as $field) {
			// get current post meta data
			$meta = get_post_meta($post->ID, $field['id'], true);
			switch ($field['type']) {
				case 'sidebarradio':
					echo '<tr>',
					'<th><label for="', esc_attr($field['id']), '"><strong>', esc_attr($field['name']), '</strong><span>' . esc_attr($field['desc']). '</span></label></th>',
					'<td>';
					if(empty($meta)){
						$meta = 'full';
					}
					foreach($field['option'] as $k=>$v){
						echo '<div class="', ($meta == $k) ? 'fishing_chooseborder '
						: '' ,'fishing-select-sidebar">
						<div style="display:none;">
						<input type="radio" value="'.esc_attr($k).'" ',($meta == $k) ? 'checked'
						: '','  name="'.esc_attr($field['id']).'" ></div>';
						echo '<img src="'.esc_url($v).'" alt="'.esc_attr('gallery image','handily').'"></div>';
					}
				break;
				case 'text':
					echo '<tr>',
					'<th><label for="', esc_attr($field['id']), '"><strong>', $field['name'], '</strong><span>' . esc_attr($field['desc']) . '</span></label></th>',
					'<td>';
					echo '<input type="text" name="', esc_attr($field['id']), '" id="', esc_attr($field['id']), '" value="', $meta ? stripslashes(htmlspecialchars(($meta), ENT_QUOTES))
						: stripslashes(htmlspecialchars(($field['std']), ENT_QUOTES)), '"/>';
                break;
				case 'select':
                echo '<tr>',
                    '<th><label for="', esc_attr($field['id']), '"><strong>', esc_html($field['name']), '</strong><span>'.esc_html($field['desc']).'</span></label></th>',
                   '<td>';
                echo'<select name="' .esc_attr($field['id']). '">';
                    foreach ($field['options'] as $k=>$v) {

                        echo'<option';
                        if ($meta == $k) {
                            echo ' selected="selected"';
                        }
                        echo' value="'.esc_attr($k).'">' .esc_html($v). '</option>';

                    }
                echo'</select>';
                break;
                case 'textarea':
                    echo '<tr class="'.($val == 'quote' ? '' : $field['cls']).'">',
                    '<th><label for="', esc_attr($field['id']), '"><strong>', esc_html($field['name']), '</strong><span>' . esc_html($field['desc']). '</span></label></th>',
                    '<td>';
                    $args = array(
                        'textarea_rows' => 5,
                        'media_buttons' => true,
                        'teeny' => true,
                        'quicktags' => true,
                        'tinymce'=> array(
                            'toolbar1'=> 'bold,italic,underline,bullist,numlist,justifyleft,justifycenter,justifyright,undo,redo'
                        )
                    );
                    wp_editor($meta ? $meta : stripslashes(htmlspecialchars(($field['std']), ENT_QUOTES)), $field['id'],$args);
                echo '</tr>';
                break;
                case 'gallery_image':
                $gallery_data = get_post_meta(get_the_ID(), 'gallery_data', true );
                echo '<tr class="'.($val == 'quote' ? '' : $field['cls']).'">';
                ?>
                <th>
                <div id="master-row">
                    <div class="field_row">
                        <div class="field_left">
                            <div class="form_field">
                                <label for="', $field['id'], '"><?php echo esc_html($field['name']); ?></label>
                                <input class="meta_image_url" value="" type="text" name="gallery[image_url][]" />
                                <span><?php echo esc_html($field['desc']); ?></span>
                            </div>
                        </div>
                        <div class="field_right image_wrap"></div> 
                        <div class="field_right"> 
                            <input type="button" class="button" value="<?php echo esc_attr__('Choose File','handily'); ?>" onclick="add_image(this)" />
                            <input class="button" type="button" value="<?php echo esc_attr__('Remove','handily'); ?>" onclick="remove_field(this)" /> 
                        </div>
                        <div class="clear"></div>
                     </div>
                     </div>
                    <div id="add_field_row">
                      <input class="button" type="button" value="<?php echo esc_attr__('Add Gallery Image','handily'); ?>" onclick="add_field_row();" />
                    </div>
                 </th>
                <th>
                <div id="dynamic_form">
                    <div id="field_wrap" class="hl-gallery-img-wrap">
                        <?php 
                        if ( isset( $gallery_data['image_url'] ) ) 
                        {
                            for( $i = 0; $i < count( $gallery_data['image_url'] ); $i++ ) 
                            {
                            ?>
                            <div class="field_row">
                                <div class="field_left">
                                <div class="form_field"> 
                                <label><?php echo esc_html__('Room Images','handily'); ?></label>
                                <input type="text" class="meta_image_url"
                                                name="gallery[image_url][]"
                                                value="<?php echo esc_url( $gallery_data['image_url'][$i] ); ?>"
                                        />
                                </div>
                            </div>
                            <div class="field_right image_wrap">
                                <img src="<?php echo esc_url( $gallery_data['image_url'][$i] ); ?>" height="<?php echo esc_attr__('100','handily'); ?>" width="<?php echo esc_attr__('100','handily'); ?>" />
                            </div>
                            <div class="field_right">
                                <input class="button" type="button" value="<?php echo esc_attr__('Choose File','handily'); ?>" onclick="add_image(this)" />
                                <input class="button" type="button" value="<?php echo esc_attr__('Remove','handily'); ?>" onclick="remove_field(this)" />
                            </div>
                            <div class="clear"></div> 
                            </div>
                            <?php
                                } 
                            } 
                            ?>
                       </div> 
                    </th>
                  <?php
                 echo '</tr>';
                break;
			}
		}
		echo '</table>';   
	}
    /**
     * Hotel Room Add Meta Option
     */
    public function hetal_save_meta_options(){	
		$page_option_meta = $this->page_option_meta;
		$new = '';
        $post_id = get_the_ID();
		// verify nonce
		if (isset($_POST['meta_box_nonce']) && !wp_verify_nonce($_POST['meta_box_nonce'], basename(__FILE__))) {
			return $post_id;
		}
		// check autosave
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return $post_id;
		}
		if (defined('DOING_AJAX') && DOING_AJAX)
			return;
		// check permissions
		if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
			if (!current_user_can('edit_page', $post_id)) {
				return $post_id;
			}
		} elseif (!current_user_can('edit_post', $post_id)) {
			return $post_id;
		}
	 
		foreach ($page_option_meta['fields'] as $field) {
			$old = get_post_meta($post_id, $field['id'], true);
			if (isset($_POST[$field['id']])) {
				 $new = $_POST[$field['id']];
			}
			if ($new && $new != $old) {
				update_post_meta($post_id, $field['id'], $new);
			} elseif ('' == $new && $old) {
				delete_post_meta($post_id, $field['id'], $old);
			}
		}
        
        if ( $_POST['gallery'] ){
            // Build array for saving post meta
            $gallery_data = array();
            for ($i = 0; $i < count( $_POST['gallery']['image_url'] ); $i++ ) 
            {
                if ( '' != $_POST['gallery']['image_url'][ $i ] ) 
                {
                    $gallery_data['image_url'][]  = $_POST['gallery']['image_url'][ $i ];
                }
            }
     
            if ($gallery_data){
                update_post_meta( $post_id, 'gallery_data', $gallery_data );
            }else{
                delete_post_meta( $post_id, 'gallery_data' );
            }
        }else {
              delete_post_meta( $post_id, 'gallery_data' );
        }

	}

}