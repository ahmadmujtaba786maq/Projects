<?php
require_once( dirname(__FILE__) . '/../../../../wp-load.php' ); // WP environment
//wp_head();
			$user_id = 1;
			$bc_table_id = '1';
			require_once plugin_dir_path( dirname( __FILE__ ) ). 'Twilio/autoload.php';
		
		//print_r($_POST); echo  'hi'; die();
		
		if(isset($_POST['razorpay_payment_id'])){
			global $wpdb; 
			$tbl_pay = $wpdb->prefix. 'cafe_table_booked';
			$wpdb->insert(
			$tbl_pay, 
			array( 
                'bc_user_id' => $user_id, 
                'bc_table_id' => $bc_table_id, 
                'bc_booking_date' => $_POST['strip_booking_date'], 
                'bc_booking_time' => $_POST['strip_booking_time'],  
                'bc_txnid' => $_POST['razorpay_payment_id'], 
                'bc_payment_amount' => $_POST['total'],  
                'bc_payment_status' => 'successfull', 
                'bc_timestamp' => date('Y-m-d H:i:s'), 
                'bc_customer_details' => json_encode($_POST), 
                'bc_payment_getway' => esc_attr__('Razorpay','handily'), 
                ) 
			);
			if($wpdb->insert_id){				
				
				$string_a = array();
				$string_a[0] = '[{payment_id}]';
				$string_a[1] = '[{name}]';
				$string_a[2] = '[{eamil}]';
				$string_a[3] = '[{phone}]';
				$string_a[4] = '[{event}]';
				$string_a[5] = '[{guests}]';
				$string_a[6] = '[{message}]';
				$string_a[7] = '[{booking_date}]';
				$string_a[8] = '[{booking_time}]';
				$string_a[9] = '[{amount}]';
				$string_a[10] = '[{total_price}]';
				$string_a[11] = '[{tax_name}]';
				$string_a[12] = '[{text_percent}]';
				
				$string_b = array();				
				$string_b[0] = $_POST['razorpay_payment_id'];
				$string_b[1] = $_POST['strip_cust_name'];
				$string_b[2] = $_POST['eamil'];
				$string_b[3] = $_POST['contact_number'];
				$string_b[4] = $_POST['event_type'];
				$string_b[5] = $_POST['num_of_guests'];
				$string_b[6] = $_POST['strip_cust_message'];
				$string_b[7] = $_POST['strip_booking_date'];
				$string_b[8] = $_POST['strip_booking_time'];
				$string_b[9] = $_POST['amount'];
				$string_b[10] = $_POST['new_price'];
				$string_b[11] = $_POST['tax_name_n'];
				$string_b[12] = $_POST['text_percent_n'];				
				
				$mail_msg = get_option('cafe_email_content');
				$email_h = get_option('cafe_email_h');
				$email_sub = get_option('cafe_email_sub');
				
				$site = get_bloginfo( 'name' );
				
				if(!empty($mail_msg)){
				        $html = preg_replace($string_a, $string_b, $mail_msg);
				} else{
				       $html = '<div class="mail_template">
				            <h1>'. $email_h .'</h1>
				            <h4>'. esc_html__('Welcome to', 'Handly'). ' '. $site .'</h4>
				            <h6>'. esc_html__('Invocie #Order', 'Handly'). ' ' . $_POST['razorpay_payment_id']. '<h6>
				            <p>'. esc_html__('Hurray!! The table has been booked for the', 'Handly'). ' '. $_POST['event_type'].' '. esc_html__('on dated', 'Handly'). ' ' . $_POST['strip_booking_date'] . ' '. esc_html__('at', 'Handly'). ' ' . $_POST['strip_booking_time'] . ''.esc_html__('.', 'Handly') .'</p>
				            <p>'. esc_html__('Lets have fun at', 'Handly').' '. $site .'</p>
				        </div>';
				}
				
    		    $web_url =$html;
				$header = '';
                $emailmessage = $email_sub;  
                $customer_email = $_POST['eamil'];
                $admin_email = get_option('admin_email');
                $headers = array('Content-Type: text/html; charset=UTF-8',$header); 
                $multiple_emails = array(
                    $admin_email, 
                    $customer_email,
                );
                wp_mail($multiple_emails, $emailmessage, $web_url, $headers);
				
				$sms = esc_html__('Thanks for making the table booking at', 'Handly').' '. $site .' '. esc_html__('Your table on dated', 'Handly') .' '. $_POST['strip_booking_date'] .' '. esc_html__(' has been booked successfully.', 'Handly');
						
				$sid = get_option('cafe_acsid');
				$token  = get_option('cafe_auth_token');
				$virfynumber  = get_option('cafe_ac_phone');
        
				$twilio = new Twilio\Rest\Client($sid, $token);
				$message = $twilio->messages 
                  ->create("+91".$_POST['contact_number'], // to 
                           array(  
                               "messagingServiceSid" => get_option('cafe_ac_mssid'),      
                               "body" => $sms,
                           ) 
                  ); 
				$message->sid;
				$razorpay_success_url = get_option('cafe_razorpay_success_url').'/?invoice='.base64_encode($wpdb->insert_id);
				$data = array('status' => 'true', 'msg' => 'Sucess', 'url' => $razorpay_success_url);
			}else{ 
				$data = array('status' => 'false', 'msg1' => $_POST);
			} 
		}
    
	echo json_encode($data);
die();
?>



