<div class="hl-main-wraper">
    <div class="container-fluid">
        <div class="hl-card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hl-hotal-tabs">
                        <ul>
                          <li>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_rooms')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/bed.png'); ?>" alt="<?php esc_attr_e('Rooms icon ','handily'); ?>"><?php echo esc_html__('Rooms','handily'); ?></a>
                          </li>
                          <li>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_booking')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/calendar.png'); ?>" alt="<?php esc_attr_e('Bookings icon','handily'); ?>"><?php echo esc_html__('Bookings','handily'); ?></a>
                          </li>
                          <li>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_payment')); ?>" class="handily_active"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/credit-card.png'); ?>" alt="<?php esc_attr_e('Payment icon','handily'); ?>"><?php echo esc_html__('Payment Settings','handily'); ?></a>
                          </li>
                          <li>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_form')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/form.png'); ?>" alt="<?php esc_attr_e('Form icon','handily'); ?>"><?php echo esc_html__('Form Settings','handily'); ?></a>
                          </li>  
                        </ul>
                    </div>
                </div>
            </div>
            <?php echo "<h1 class='hl-heading-title'>".esc_html__('Payment API Settings','handily')."</h1>"; ?>
            <div class="hl-vertical-tab">
                <div class="nav" id="v-pills-tab" role="tablist" aria-orientation="vertical">
					<button class="nav-link active" data-bs-toggle="pill" data-bs-target="#hl-general">
                    <?php echo esc_html__('General','handily'); ?></button>
                    <button class="nav-link " data-bs-toggle="pill" data-bs-target="#hl-stripe">
                    <?php echo esc_html__('Stripe','handily'); ?></button>
					<button class="nav-link" data-bs-toggle="pill" data-bs-target="#hl-razorpay">
                    <?php echo esc_html__('Razorpay','handily'); ?></button>
                </div>
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="tab-pane fade show active" id="hl-general" role="tabpanel">
						<form name="payment_setting" id="payment_setting" action="" method="post">
							<?php 
								$curreny_val = get_option('curreny_val');	
								$tax_title = get_option('tax_title');	
								$text_percent = get_option('text_percent');					
							?>
							<ul>
								<li><label for="curreny_val"><?php echo esc_html__('Currency','handily'); ?></label>
									<?php 
									$currency_sym = array( 
										'AED' => 'د.إ',  
										'AFN' => '؋',  
										'ALL' => 'L',  
										'AMD' => 'AMD',  
										'ANG' => 'ƒ',  
										'AOA' => 'Kz',  
										'ARS' => '$',  
										'AUD' => '$',  
										'AWG' => 'ƒ',  
										'AZN' => 'AZN',  
										'BAM' => 'KM',  
										'BBD' => '$',  
										'BDT' => '৳ ',  
										'BGN' => 'лв.',  
										'BHD' => '.د.ب',  
										'BIF' => 'Fr',  
										'BMD' => '$',  
										'BND' => '$',  
										'BOB' => 'Bs.',  
										'BRL' => 'R$',  
										'BSD' => '$',  
										'BTC' => '฿',  
										'BTN' => 'Nu.',  
										'BWP' => 'P',  
										'BYR' => 'Br',  
										'BZD' => '$',  
										'CAD' => '$',  
										'CDF' => 'Fr',  
										'CHF' => 'CHF',  
										'CLP' => '$',  
										'CNY' => '¥',  
										'COP' => '$',  
										'CRC' => '₡',  
										'CUC' => '$',  
										'CUP' => '$',  
										'CVE' => '$',  
										'CZK' => 'Kč',  
										'DJF' => 'Fr',  
										'DKK' => 'DKK',  
										'DOP' => 'RD$',  
										'DZD' => 'د.ج',  
										'EGP' => 'EGP',  
										'ERN' => 'Nfk',  
										'ETB' => 'Br',  
										'EUR' => '€',  
										'FJD' => '$',  
										'FKP' => '£',  
										'GBP' => '£',  
										'GEL' => 'ლ',  
										'GGP' => '£',  
										'GHS' => '₵',  
										'GIP' => '£',  
										'GMD' => 'D',  
										'GNF' => 'Fr',  
										'GTQ' => 'Q',  
										'GYD' => '$',  
										'HKD' => '$',  
										'HNL' => 'L',  
										'HRK' => 'Kn',  
										'HTG' => 'G',  
										'HUF' => 'Ft',  
										'IDR' => 'Rp',  
										'ILS' => '₪',  
										'IMP' => '£',  
										'INR' => '₹',  
										'IQD' => 'ع.د',  
										'IRR' => '﷼',  
										'IRT' => 'تومان',  
										'ISK' => 'kr.',  
										'JEP' => '£',  
										'JMD' => '$',  
										'JOD' => 'د.ا',  
										'JPY' => '¥',  
										'KES' => 'KSh',  
										'KGS' => 'сом',  
										'KHR' => '៛',  
										'KMF' => 'Fr',  
										'KPW' => '₩',  
										'KRW' => '₩',  
										'KWD' => 'د.ك',  
										'KYD' => '$',  
										'KZT' => 'KZT',  
										'LAK' => '₭',  
										'LBP' => 'ل.ل',  
										'LKR' => 'රු',  
										'LRD' => '$',  
										'LSL' => 'L',  
										'LYD' => 'ل.د',  
										'MAD' => 'د.م.',  
										'MDL' => 'MDL',  
										'MGA' => 'Ar',  
										'MKD' => 'ден',  
										'MMK' => 'Ks',  
										'MNT' => '₮',  
										'MOP' => 'P',  
										'MRO' => 'UM',  
										'MUR' => '₨',  
										'MVR' => '.ރ',  
										'MWK' => 'MK',  
										'MXN' => '$',  
										'MYR' => 'RM',  
										'MZN' => 'MT',  
										'NAD' => '$',  
										'NGN' => '₦',  
										'NIO' => 'C$',  
										'NOK' => 'kr',  
										'NPR' => '₨',  
										'NZD' => '$',  
										'OMR' => 'ر.ع.',  
										'PAB' => 'B/.',  
										'PEN' => 'S/.',  
										'PGK' => 'K',  
										'PHP' => '₱',  
										'PKR' => '₨',  
										'PLN' => 'zł',  
										'PRB' => 'р.',  
										'PYG' => '₲',  
										'QAR' => 'ر.ق',  
										'RMB' => '¥',  
										'RON' => 'lei',  
										'RSD' => 'дин.',  
										'RUB' => '₽',  
										'RWF' => 'Fr',  
										'SAR' => 'ر.س',  
										'SBD' => '$',  
										'SCR' => '₨',  
										'SDG' => 'ج.س.',  
										'SEK' => 'kr',  
										'SGD' => '$',  
										'SHP' => '£',  
										'SLL' => 'Le',  
										'SOS' => 'Sh',  
										'SRD' => '$',  
										'SSP' => '£',  
										'STD' => 'Db',  
										'SYP' => 'ل.س',  
										'SZL' => 'L',  
										'THB' => '฿',  
										'TJS' => 'ЅМ',  
										'TMT' => 'm',  
										'TND' => 'د.ت',  
										'TOP' => 'T$',  
										'TRY' => '₺',  
										'TTD' => '$',  
										'TWD' => 'NT$',  
										'TZS' => 'Sh',  
										'UAH' => '₴',  
										'UGX' => 'UGX',  
										'USD' => '$',  
										'UYU' => '$',  
										'UZS' => 'UZS',  
										'VEF' => 'Bs F',  
										'VND' => '₫',  
										'VUV' => 'Vt',  
										'WST' => 'T',  
										'XAF' => 'Fr',  
										'XCD' => '$',  
										'XOF' => 'Fr',  
										'XPF' => 'Fr',  
										'YER' => '﷼',  
										'ZAR' => 'R',  
										'ZMW' => 'ZK',  
									);
									?>
									<select name="curreny_val" id="curreny_val" >
										<?php foreach($currency_sym as $currency => $sym): 
										?>
											<option value="<?php echo esc_attr($currency); ?>" <?php if($curreny_val == $currency): echo"selected"; endif; ?>>
											<?php echo esc_html($sym); ?></option>
										<?php endforeach; ?> 
									</select>
								</li>
								<li><label for="tax_title"><?php echo esc_html__('Add Tax Title','handily'); ?></label>
									<input type="text" name="tax_title" id="tax_title" value="<?php echo esc_attr($tax_title); ?>">
								</li>
								<li><label for="text_percent"><?php echo esc_html__('Add Tax in %','handily'); ?></label>
									<input type="number" name="text_percent" id="text_percent" value="<?php echo esc_attr($text_percent); ?>">
								</li>
							</ul>
							<button class="hl-btn">
								<?php echo esc_html__('Save Details','handily'); ?>
							</button> 
						</form>
					</div>
					<div class="tab-pane fade" id="hl-stripe" role="tabpanel">
						<form name="stripe_payment" id="stripe_payment" action="" method="post">
							<?php 
								$publishbale_key = get_option('stripe_publishbale_key');
								$secret_key = get_option('stripe_secret_key');
								$stripe_email = get_option('stripe_email');
								$success_url = get_option('stripe_success_url');
								$cancel_url = get_option('stripe_cancel_url');
							?>
							<ul>
								<li>
									<label for="stripe_publishbale_key"><?php echo esc_html__('Stripe Publishable key','handily'); ?></label>
									<input type="text" name="stripe_publishbale_key" id="stripe_publishbale_key" value="<?php echo esc_attr($publishbale_key); ?>">
								</li>
								<li>
									<label for="stripe_secret_key"><?php echo esc_html__('Stripe Secret key','handily'); ?></label>
									<input type="text" name="stripe_secret_key" id="stripe_secret_key" value="<?php echo esc_attr($secret_key); ?>">
								</li>
								<li>
									<label for="stripe_email"><?php echo esc_html__('Stripe Email','handily'); ?></label>
									<input type="text" name="stripe_email" id="stripe_email" value="<?php echo esc_attr($stripe_email); ?>">
								</li>
								<li>
									<label for="stripe_success_url"><?php echo esc_html__('Stripe Success Url','handily'); ?></label>
									<input type="text" name="stripe_success_url" id="stripe_success_url" value="<?php echo esc_attr($success_url); ?>">
								</li>
								<li>
									<label for="stripe_cancel_url"><?php echo esc_html__('Stripe Cancel Url','handily'); ?></label>
									<input type="text" name="stripe_cancel_url" id="stripe_cancel_url" value="<?php echo esc_attr($cancel_url); ?>">
								</li>
							</ul>
							<button class="hl-btn">
								<?php echo esc_html__('Save Details','handily'); ?>
							</button> 
						</form>
					</div>
					<div class="tab-pane fade" id="hl-razorpay" role="tabpanel">
						<form name="razorpay_payment" id="razorpay_payment" action="" method="post">
							<?php 
								$razorpay_key = get_option('razorpay_key');
								$razorpay_success_url = get_option('razorpay_success_url');
								$razorpay_cancel_url = get_option('razorpay_cancel_url');
							?>
							<ul>
								<li>
									<label for="razorpay_key"><?php echo esc_html__('Razorpay key','handily'); ?></label>
									<input type="text" name="razorpay_key" id="razorpay_key" value="<?php echo esc_attr($razorpay_key); ?>">
								</li>
								<li>
									<label for="razorpay_success_url"><?php echo esc_html__('Razorpay Success Url','handily'); ?></label>
									<input type="text" name="razorpay_success_url" id="razorpay_success_url" value="<?php echo esc_attr($razorpay_success_url); ?>">
								</li>
								<li>
									<label for="razorpay_cancel_url"><?php echo esc_html__('Razorpay Cancel url','handily'); ?></label>
									<input type="text" name="razorpay_cancel_url" id="razorpay_cancel_url" value="<?php echo esc_attr($razorpay_cancel_url); ?>">
								</li>
							</ul>
							<button class="hl-btn">
								<?php echo esc_html__('Save Details','handily'); ?>
							</button> 
						</form>
					</div>
                </div>
            </div>
        </div>
        <!-- Loader Section Start  -->
        <div class="hl-preloader">
            <div class="hl-preloader-box">
            <svg xmlns="http://www.w3.org/2000/svg" width="200px" height="200px" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
                <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="0s"></animate>
                <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="0s"></animate>
                </circle><circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
                <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
                <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
                </circle>
            </svg>
            </div>
        </div>
      <!-- Loader Section End -->
    </div>
</div>