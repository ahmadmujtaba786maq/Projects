<?php
require_once( dirname(__FILE__) . '/../../../../wp-load.php' ); // WP environment
//wp_head();
			$user_id = 1;
			$requirement = '';
			$requests = '';
			$contact_number = $_POST['contact_number'];
			require_once plugin_dir_path( dirname( __FILE__ ) ). 'Twilio/autoload.php';
		
		//print_r($_POST); echo  'hi'; die();
		
		if(isset($_POST['razorpay_payment_id'])){
			global $wpdb; 
			$tbl_pay = $wpdb->prefix. 'hotel_room_booked';
			$wpdb->insert(
			$tbl_pay, 
			array(
			    'b_user_id' => $user_id, 
                'b_room_id' => $_POST['item_id'], 
                'b_start_date' => $_POST['check_in'], 
                'b_end_date' => $_POST['check_out'], 
                'b_adults' => $_POST['badults'], 
                'b_children' => $_POST['bchildren'], 
                'b_requirement' => $requirement, 
                'b_requests' => $requests, 
                'b_txnid' => $_POST['razorpay_payment_id'], 
                'b_payment_amount' => $_POST['new_price'], 
                'b_payment_status' => 'successfull', 
                'b_timestamp' => date('Y-m-d H:i:s'), 
                'b_customer_details'=> json_encode($_POST), 
                'b_payment_getway' => 'razorpay', 
				'b_hash' => 'testmode',
                ) 
			);
			if($wpdb->insert_id){				
				
				$string_a = array();
				$string_a[0] = '[{payment_id}]';
				$string_a[1] = '[{first_name}]';
				$string_a[2] = '[{last_name}]';
				$string_a[3] = '[{peoples}]';
				$string_a[4] = '[{price}]';
				$string_a[5] = '[{check_in}]';
				$string_a[6] = '[{check_out}]';
				$string_a[7] = '[{adults}]';
				$string_a[8] = '[{children}]';
				$string_a[9] = '[{phone}]';
				$string_a[10] = '[{eamil}]';
				$string_a[11] = '[{total_price}]';
				$string_a[12] = '[{tax_name}]';
				$string_a[13] = '[{text_percent}]';
				
				$string_b = array();				
				$string_b[0] = $_POST['razorpay_payment_id'];
				$string_b[1] = $_POST['first_name'];
				$string_b[2] = $_POST['last_name'];
				$string_b[3] = $_POST['num_of_peoples'];
				$string_b[4] = $_POST['room_price'];
				$string_b[5] = $_POST['check_in'];
				$string_b[6] = $_POST['check_out'];
				$string_b[7] = $_POST['badults'];
				$string_b[8] = $_POST['bchildren'];
				$string_b[9] = $_POST['contact_number'];
				$string_b[10] = $_POST['eamil'];
				$string_b[11] = $_POST['new_price'];
				$string_b[12] = $_POST['tax_name_n'];
				$string_b[13] = $_POST['text_percent_n'];				
				
				$mail_msg = get_option('email_content');
				$email_h = get_option('email_h');
				$email_sub = get_option('email_sub');
				
				if(!empty($mail_msg)){
				        $html = preg_replace($string_a, $string_b, $mail_msg);
				} else{
				       $html = '<div class="mail_template">
				            <h4>'. esc_html__('Welcome to Handily Booking system', 'Handly'). '</h4>
				            <h6>'. esc_html__('Invocie #Order', 'Handly'). ' ' . $_POST['razorpay_payment_id']. '<h6>
				            <p>'. esc_html__('Congratulations for the successful booking for the', 'Handly'). ' '. $num_of_peoples .' '. esc_html__('people on dated', 'Handly'). ' ' . $start_date . ' '. esc_html__('to', 'Handly'). ' ' . $end_date . ''.esc_html__('Enjoy your journey / trip.', 'Handly') .'</p>
				        </div>';
				}
				
    		    $web_url =$html;
				$header = '';
                $emailmessage = $email_sub;  
                $customer_email = $_POST['eamil'];
                $admin_email = get_option('admin_email');
                $headers = array('Content-Type: text/html; charset=UTF-8',$header); 
                $multiple_emails = array(
                    $admin_email, 
                    $customer_email,
                );
                wp_mail($multiple_emails, $emailmessage, $web_url, $headers);
				
						
				$sid = get_option('acsid');
				if(!empty($sid)){
				$token  = get_option('auth_token');
				$virfynumber  = get_option('ac_phone');
        
				$twilio = new Twilio\Rest\Client($sid, $token);
				$message = $twilio->messages 
                  ->create("+91".$contact_number, // to 
                           array(  
                               "messagingServiceSid" => get_option('ac_mssid'),      
                               "body" => 'Welcome to Handily Booking system. Congratulations for the successful booking. Enjoy  your journey/ trip',
                           ) 
                  ); 
				$message->sid;
				}
				$razorpay_success_url = get_option('razorpay_success_url').'/?invoice='.base64_encode($wpdb->insert_id);
				$data = array('status' => 'true', 'msg' => 'Sucess', 'url' => $razorpay_success_url);
			}else{ 
				$data = array('status' => 'false', 'msg' => 'Failed');
			} 
		}
    
	echo json_encode($data);
die();
?>



