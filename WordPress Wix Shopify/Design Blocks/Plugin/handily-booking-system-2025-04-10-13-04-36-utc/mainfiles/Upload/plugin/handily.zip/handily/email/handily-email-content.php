<!doctype html>
<html>
<head>
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Email template</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body style="margin:0;">
    <!-- body -->
    <table cellpadding="0" cellspacing="0" border="0" style="background-color:#e6e6e6; font-family: 'Lato', sans-serif; width:100%;">
        <tr>
            <td>
                <table cellpadding="0" cellspacing="0" border="0" style="padding: 80px 20px;padding-bottom: 0; width: 600px;margin:0 auto; margin-bottom:80px; border: none;background-image: url('https://kamleshyadav.com/plugin/handily/wp-content/uploads/2021/11/back_email.png');background-position: center bottom;background-repeat: no-repeat;border-radius: 10px; background-size: contain;">
                    <tr>
                        <td style="border: none;clear: both !important;background-color:#ffffff;display: block !important;Margin: 0 auto !important;max-width: 600px !important;border-radius: 10px;">
                            <table align="center" cellpadding="0" cellspacing="0" border="0" style="width: 100%; border: none;border: none;">
                                <tr style="-webkit-font-smoothing: antialiased;  height: 100%;  -webkit-text-size-adjust: none;  width: 100% !important;">
                                    <td align="center" style=" float: left; padding: 25px 0px;text-align: center;width:100%;background:#201d1d;border-radius: 4px 4px 0px 0px;">
                                        <span style="padding-right: 10px;text-align: center;display:inline-block;">
										<img src="./logo.png" alt="" width="120px"/>
										</span>
                                    </td>
                                </tr>
                            </table>

                            <table cellpadding="0" cellspacing="0" border="0" style=" width: 100%; padding:20px;border: none;">
                                <tr>
                                    <td style="height:20px;"></td>
                                </tr>
                                <tr>
                                    <td style="height:15px;"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="font-size:26px; color:#333333;text-transform: capitalize;text-align: center;font-weight: 600;">
                                        Hotal Handily Confirmation Paymenyt
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2" style="height:10px;"></td>
                                </tr>
                              
                                <tr>
                                    <td colspan="2" style="font-size:18px; color:#78849b;text-align: center;font-weight: 600;">
                                    <?php
                                     echo get_option('email_form_content');
                                    ?>
                                </tr>
                                <!--
                                <tr>
                                    <td colspan="2" style="height:25px;"></td>
                                </tr>

                                <tr>
                                    <td>
                                        Check In Date:
                                    </td>
                                    <td>
                                        <b>2021-11-27</b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        Check Out Date:
                                    </td>
                                    <td>
                                        <b>2021-12-23</b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        First Name:
                                    </td>
                                    <td>
                                        <b>ajay</b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        Last Name:
                                    </td>
                                    <td>
                                        <b>singh</b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        Eamil Address:
                                    </td>
                                    <td>
                                        <b>ajay.shrivas@himanshusofttech.com</b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        Address:
                                    </td>
                                    <td>
                                        <b>Dewas</b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        Room Type:
                                    </td>
                                    <td>
                                        <b>superior-room</b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        Pay Amount:
                                    </td>
                                    <td>
                                        <b>Rs1500</b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        Transaction ID:
                                    </td>
                                    <td>
                                        <b>txn_3JuwuoDn0Yc5TNXR3b9dFNQh</b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        Payment Status:
                                    </td>
                                    <td>
                                        <b>succeeded</b>
                                    </td>
                                </tr>
                                -->

                                <tr>
                                    <td colspan="2" style="height:15px;"></td>
                                </tr>

                                <tr>
                                    <td colspan="2" style="height:20px;"></td>
                                </tr>

                                <tr>
                                    <td colspan="2">
                                        <table style="width: 100%;">

                                            <tr>
                                                <td style="height:10px;"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align: center;">
                                                    <a href="#" style="height: 56px;line-height: 56px;font-size: 18px; font-weight: 600; outline: none;border: none;display: inline-block;padding: 0 40px;    border-radius: 5px;text-transform: capitalize;text-decoration: none;color: #FFFFFF;box-shadow: 0px 0px 30px 0px rgb(0 0 0 / 15%); background: #ff8f91;">
                                                        Visit Site
                                                    </a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="height:20px;"></td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2" style="font-size:15px; color:#78849b;text-align: center;">Please don't reply to this email. This email is not monitored. If you need customer support.</td>
                                </tr>
                            </table>

                            <table cellpadding="0" cellspacing="0" border="0" style=" border: none; width: 100%; padding:26px; background-image:url('https://kamleshyadav.com/plugin/handily/wp-content/uploads/2021/11/front_email.png'); background-size: cover; background-repeat: no-repeat; background-position: top;">
                                <tr>
                                    <td style="height:171px;"></td>
                                </tr>

                                <tr>
                                    <td style="height:20px;"></td>
                                </tr>

                                <tr>
                                    <td style="font-size:16px; color:#ffffff; text-align:center; font-weight:500;">Copyright &copy; 2021
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height:15px;"></td>
                                </tr>
                                <tr>
                                    <td style="font-size:16px; color:#ffffff; text-align:center; font-weight:500;">
                                        Handly Plugin
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height:20px;"></td>
                                </tr>

                            </table>

                            </td>
                    </tr>
                </table>
                </td>
        </tr>
    </table>
    <!-- /body -->
</body>
</html>