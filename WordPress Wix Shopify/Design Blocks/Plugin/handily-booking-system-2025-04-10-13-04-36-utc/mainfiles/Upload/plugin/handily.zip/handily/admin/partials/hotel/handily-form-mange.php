<div class="hl-main-wraper">
   <div class="container-fluid">
        <div class="hl-card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hl-hotal-tabs">
                        <ul>
                            <li>
                             <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_rooms')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/bed.png'); ?>" alt="<?php esc_attr_e('Rooms icon ','handily'); ?>"><?php echo esc_html__('Rooms','handily'); ?></a>
                            </li>
                            <li>
                             <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_booking')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/calendar.png'); ?>" alt="<?php esc_attr_e('Bookings icon','handily'); ?>"><?php echo esc_html__('Bookings','handily'); ?></a>
                            </li>
                            <li>
                              <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_payment')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/credit-card.png'); ?>" alt="<?php esc_attr_e('Payment icon','handily'); ?>"><?php echo esc_html__('Payment Settings','handily'); ?></a>
                            </li>
                            <li>
                              <a href="<?php echo esc_url(admin_url('admin.php?page=hotel_form')); ?>" class="handily_active"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/form.png'); ?>" alt="<?php esc_attr_e('Form icon','handily'); ?>"><?php echo esc_html__('Form Settings','handily'); ?></a>
                            </li>  
                        </ul>
                    </div>
                </div>
            </div>
            <?php echo "<h1 class='hl-heading-title'>".esc_html__('Form Settings','handily')."</h1>"; ?>
            <div class="hl-vertical-tab">
                <div class="nav" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#hl-form-shortcode">
                    <?php echo esc_html__('Shortcode','handily'); ?></button>
                    <button class="nav-link" data-bs-toggle="pill" data-bs-target="#h1-form-option-setting">
                    <?php echo esc_html__('Custom Settings','handily'); ?></button>
					<button class="nav-link" data-bs-toggle="pill" data-bs-target="#h1-form-sms-setting">
                    <?php echo esc_html__('SMS Settings','handily'); ?></button>
					<button class="nav-link" data-bs-toggle="pill" data-bs-target="#h1-form-email-setting">
                    <?php echo esc_html__('Email Settings','handily'); ?></button>
					<button class="nav-link" data-bs-toggle="pill" data-bs-target="#h1-form-color-setting">
                    <?php echo esc_html__('Color Settings','handily'); ?></button>
                </div>
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="tab-pane fade show active" id="hl-form-shortcode" role="tabpanel">
                      <p><?php echo esc_html__('Room View Shortcode For Customer , Customer can find room and book [hendily_room_views]','handily'); ?></p>
                      <p><?php echo esc_html__('Payment Review Shortcode For Customer , Customer View Affter Payment and Get Print [room_booking_invoice]','handily'); ?></p>
                    </div> 
                    <div class="tab-pane fade show" id="h1-form-option-setting" role="tabpanel">
                        <form name="hotel_custom_option" id="hotel_custom_option" method="post">
                        <?php  
                        $booking_form_heading = get_option('hotel_booking_form_heading');
                        $booking_review_heading = get_option('hotel_booking_review_heading');
                        $payment_form_heading = get_option('hotel_payment_form_heading');
                        $booking_invoice_heading = get_option('hotel_booking_invoice_heading');
                        ?> 
                        <ul>
                        <li>
                            <label for="hotel_booking_form_heading"><?php echo esc_html__('Booking Form Heading','handily'); ?></label>
                            <input type="text" name="hotel_booking_form_heading" id="hotel_booking_form_heading" value="<?php echo esc_attr($booking_form_heading); ?>">
                        </li>
                        <li>
                            <label for="hotel_booking_review_heading"><?php echo esc_html__('Form Review Heading','handily'); ?></label>
                            <input type="text" name="hotel_booking_review_heading" id="hotel_booking_review_heading" value="<?php echo esc_attr($booking_review_heading); ?>">   
                        </li>
                        <li>
                            <label for="hotel_payment_form_heading"><?php echo esc_html__('Payment Form Heading','handily'); ?></label>
                            <input type="text" name="hotel_payment_form_heading" id="hotel_payment_form_heading" value="<?php echo esc_attr($payment_form_heading); ?>"> 
                        </li> 
                        <li>
                            <label for="hotel_booking_invoice_heading"><?php echo esc_html__('Confirmation Payment Heading','handily'); ?></label>
                            <input type="text" name="hotel_booking_invoice_heading" id="hotel_booking_invoice_heading" value="<?php echo esc_attr($booking_invoice_heading); ?>">    
                        </li>  
                        </ul>
                        <button class="hl-btn">
                            <?php echo esc_html__('Save','handily'); ?>
                        </button> 
                        </form>
                    </div> 					
					<div class="tab-pane fade" id="h1-form-sms-setting" role="tabpanel">
                        <form name="hotel_sms_option" id="hotel_sms_option" method="post">
                        <?php  
							$acsid = get_option('acsid');
							$auth_token = get_option('auth_token');
							$ac_phone = get_option('ac_phone');
							$ac_mssid = get_option('ac_mssid');
							$ac_msg = get_option('ac_msg');
                        ?> 
                        <ul>
                        <li>
                            <label for="acsid"><?php echo esc_html__('Account SID','handily'); ?></label>
                            <input type="text" name="acsid" id="acsid" value="<?php echo esc_attr($acsid); ?>">
                        </li>
                        <li>
                            <label for="auth_token"><?php echo esc_html__('Auth Token','handily'); ?></label>
                            <input type="text" name="auth_token" id="auth_token" value="<?php echo esc_attr($auth_token); ?>">   
                        </li>
                        <li>
                            <label for="ac_phone"><?php echo esc_html__('Phone Number','handily'); ?></label>
                            <input type="text" name="ac_phone" id="ac_phone" value="<?php echo esc_attr($ac_phone); ?>"> 
                        </li> 
                        <li>
                            <label for="ac_mssid"><?php echo esc_html__('Messaging Service Sid','handily'); ?></label>
                            <input type="text" name="ac_mssid" id="ac_mssid" value="<?php echo esc_attr($ac_mssid); ?>">    
                        </li>  
                        </ul>
                        <button class="hl-btn">
                            <?php echo esc_html__('Save','handily'); ?>
                        </button> 
                        </form>
                    </div> 
					<div class="tab-pane fade" id="h1-form-color-setting" role="tabpanel">
						<form name="hotel_email_option" id="hotel_color_option" method="post">
						<?php  
							$primary_color = get_option('primary_color');
							$gc_color = get_option('gc_color');
							$gcc_color = get_option('gcc_color');
                        ?> 
						<ul>
							<li>
								<label for="primary_color"><?php echo esc_html__('Primary Color','handily'); ?></label>
								<input type="color" name="primary_color" id="primary_color" value="<?php echo esc_attr($primary_color); ?>">
							</li>
							<li>
								<label for="gc_color"><?php echo esc_html__('Gradient Color First','handily'); ?></label>
								<input type="color" name="gc_color" id="gc_color" value="<?php echo esc_attr($gc_color); ?>">
							</li>
							<li>
								<label for="gcc_color"><?php echo esc_html__('Gradient Second','handily'); ?></label>
								<input type="color" name="gcc_color" id="gcc_color" value="<?php echo esc_attr($gcc_color); ?>">
							</li>
						</ul>
						<button class="hl-btn">
                            <?php echo esc_html__('Save','handily'); ?>
                        </button> 
                        </form>
					</div>
					<div class="tab-pane fade" id="h1-form-email-setting" role="tabpanel">
                        <form name="hotel_email_option" id="hotel_email_option" method="post">
                        <?php  
							$email_h = get_option('email_h');
							$email_sub = get_option('email_sub');
							$email_content = get_option('email_content');
                        ?> 
                        <ul>
                        <li>
                            <label for="email_h"><?php echo esc_html__('Email Heading','handily'); ?></label>
                            <input type="text" name="email_h" id="email_h" value="<?php echo esc_attr($email_h); ?>">
                        </li>
                        <li>
                            <label for="email_sub"><?php echo esc_html__('Email Subject','handily'); ?></label>
                            <input type="text" name="email_sub" id="email_sub" value="<?php echo esc_attr($email_sub); ?>">   
                        </li>						
                        </ul>
                        <div class="hotel_email_form_content_area">
                            <label for="email_content"><?php echo esc_html__('Email Form Content','handily'); ?></label>
                            <?php wp_editor($email_content, 'email_content'); ?>
							<p><em><?php echo esc_html__('Use string Create Order email  : {payment_id}, {first_name}, {last_name}, {peoples},{price}, {check_in}, {check_out}, {adults}, {children}, {phone}, {eamil}, {total_price}, {tax_name}, {text_percent}', 'handily'); ?><em></p>
                        </div> 
                        <button class="hl-btn">
                            <?php echo esc_html__('Save','handily'); ?>
                        </button> 
                        </form>
                    </div> 
                </div>
            </div>
         </div>
            <!-- Loader Section Start  -->
            <div class="hl-preloader">
              <div class="hl-preloader-box">
              <svg xmlns="http://www.w3.org/2000/svg" width="200px" height="200px" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
                  <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="0s"></animate>
                  <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="0s"></animate>
                  </circle><circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
                  <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
                  <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
                  </circle>
              </svg>
              </div>
            </div>
          <!-- Loader Section End -->
    </div>
</div>