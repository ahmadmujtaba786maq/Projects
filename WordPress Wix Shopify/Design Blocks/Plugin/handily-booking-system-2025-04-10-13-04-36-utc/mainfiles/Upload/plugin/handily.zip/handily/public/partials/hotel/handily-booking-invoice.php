<div class="hl-spacer-top hl-spacer-bottom hl-booking-invoice">
    <div class="container">
        <div class="row" id="hl-booking-invoice">
            <div class="col-md-12">
                <div class="hl-payment-handily">
                    <div class="hl-payment-header">
                        <div class="hl-payment-site-name">
                            <?php 
                            $booking_invoice_heading = get_option('hotel_booking_invoice_heading');
                            if(!empty($booking_invoice_heading)):
                            ?><h2><?php echo esc_html($booking_invoice_heading); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                    <ul>
                    <?php 
                    if(isset($_GET['invoice'])):
                    global $wpdb;
                    $b_id = base64_decode($_GET['invoice']);
                    $pmt_tbl = $wpdb->prefix . 'hotel_room_booked';
                    $booking_query = $wpdb->get_results("SELECT * FROM $pmt_tbl WHERE b_id in($b_id)"); 
                    if($booking_query) {  
                        foreach ($booking_query as $booking) {
                            $customer_details = json_decode($booking->b_customer_details);
                            $first_name = '';
                            if(!empty($customer_details->first_name)):
                            $first_name = $customer_details->first_name;
                            endif;
                            $last_name = '';
                            if(!empty($customer_details->last_name)):
                            $last_name = $customer_details->last_name;
                            endif;
                            $eamil = '';
                            if(!empty($customer_details->eamil)):
                            $eamil = $customer_details->eamil;
                            endif;
                            $contact_number = '';
                            if(!empty($customer_details->contact_number)):
                            $contact_number = $customer_details->contact_number;
                            endif;
                            $address = '';
                            if(!empty($customer_details->address)):
                            $address = $customer_details->address;
                            endif;
                            $room_type = '';
                            if(!empty($customer_details->room_type)):
                            $room_type = $customer_details->room_type;
                            endif;
                            if(!empty($booking->b_start_date)):
                            ?>
                            <li><span><?php esc_html_e('Check In Date:','handily'); ?></span><?php echo esc_html($booking->b_start_date); ?></li>
                            <?php endif; 
                            if(!empty($booking->b_end_date)):
                            ?>
                            <li><span><?php esc_html_e('Check Out Date:','handily'); ?></span><?php echo esc_html($booking->b_end_date); ?></li> 
                            <?php endif; 
                            if(!empty($first_name)):
                            ?>
                            <li><span><?php esc_html_e('First Name:','handily'); ?></span><?php echo esc_html($first_name); ?></li>
                            <?php 
                            endif; 
                            if(!empty($last_name)):
                            ?>
                            <li><span><?php esc_html_e('Last Name:','handily'); ?></span><?php echo esc_html($last_name); ?></li>
                            <?php endif; 
                            if(!empty($eamil)):
                            ?>
                            <li><span><?php esc_html_e('Eamil Address:','handily'); ?></span><?php echo esc_html($eamil); ?></li>
                            <?php 
                            endif;
                            if(!empty($address)):
                            ?>
                            <li><span><?php esc_html_e('Address:','handily'); ?></span><?php echo esc_html($address); ?></li>
                            <?php 
                            endif;
                            if(!empty($room_type)):
                            ?>
                            <li><span><?php esc_html_e('Room Type:','handily'); ?></span><?php echo esc_html($room_type); ?></li>
                            <?php 
                            endif;
                            }
                            $price_currency = get_post_meta($booking->b_room_id,'hotel_currency',true);
                            if(!empty($price_currency) && !empty($booking->b_payment_amount)):
                            ?>
                            <li><span><?php esc_html_e('Pay Amount:','handily'); ?></span>
                            <?php echo esc_html($price_currency).''.esc_html($booking->b_payment_amount); ?></li>
                            <?php 
                            endif;
                            if(!empty($booking->b_txnid)):
                            ?>
                            <li><span><?php esc_html_e('Transaction ID:','handily'); ?></span>
                            <?php echo esc_html($booking->b_txnid); ?></li>
                            <?php  
                            endif;
                            
                            if(!empty($booking->b_payment_status)):
                            ?>
                            <li><span><?php esc_html_e('Payment Status:','handily'); ?></span><?php echo esc_html($booking->b_payment_status); ?></li>
                            <?php 
                            endif;
                        }
                    ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div> 
        </div>
       <a href="javascript:void(0)" id="hl_print_button" class="hl-btn"><?php echo esc_html__('Print','handily'); ?></a>
   </div>
</div> 