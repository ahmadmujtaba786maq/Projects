<div class="hl-main-wraper">
   <div class="container-fluid">
        <div class="hl-card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hl-hotal-tabs">
                        <ul>  
                            <li>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_schedule')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/bed.png'); ?>" alt="<?php esc_attr_e('Schedule Icon ','handily'); ?>"><?php echo esc_html__('Schedule','handily'); ?></a> 
                            </li> 
                            <li> 
                             <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_booking')); ?>" class="handily_active"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/calendar.png'); ?>" alt="<?php esc_attr_e('Bookings icon','handily'); ?>"><?php echo esc_html__('Bookings','handily'); ?></a>
                            </li>
                            <li>
                             <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_paymentsetting')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/credit-card.png'); ?>" alt="<?php esc_attr_e('Payment icon','handily'); ?>"><?php echo esc_html__('Payment Settings','handily'); ?></a>
                            </li>
                            <li>
                             <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_formsetting')); ?>"><img src="<?php echo esc_url(plugins_url(). '/handily/admin/images/form.png'); ?>" alt="<?php esc_attr_e('Form icon','handily'); ?>"><?php echo esc_html__('Form Settings','handily'); ?></a> 
                            </li> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <form method="get" class="user-form-listing">
            <input type="hidden" name="post_type" value="<?php echo esc_attr__('appointment','handily'); ?>" /> 
            <input type="hidden" name="page" value="<?php echo wp_kses($_REQUEST['page'],true); ?>" />
			<a href="javascript:void(0);" class="hl-btn" id="xlsexport"><?php echo esc_html__('Xls Export','handily'); ?></a>
				<a href="javascript:void(0);" class="hl-btn" id="csvexport"><?php echo esc_html__('CSV Export','handily'); ?></a>
            <?php 
            echo "<h1 class='hl-heading-title'>".esc_html__('Booking List','handily')."</h1>";
            require dirname( __FILE__ ) . '/handily-appointment-data-list.php'; 
            $list_table = new handily_appointment_booking_list(); 
            $list_table->prepare_items();
            $list_table->search_box('Search', 'search');
            ?>
            <div class="hl-table-wrapper">
               <?php $list_table->display(); ?>
            </div>  
        </form> 
        <!-- Loader Section Start  -->
        <div class="hl-preloader">
              <div class="hl-preloader-box">
              <svg xmlns="http://www.w3.org/2000/svg" width="200px" height="200px" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
                  <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="0s"></animate>
                  <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="0s"></animate>
                  </circle><circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
                  <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
                  <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
                  </circle>
              </svg>
              </div>
        </div>
        <!-- Loader Section End -->
    </div>
</div>