<?php
/***
 * Handily Custom Post Type For Create Schedule 
 */
$r_labels = array(
    'name' => esc_html__( 'Handily Schedule', 'handily' ),
    'singular_name' => esc_html__( 'Handily Schedule', 'handily' ),
    'menu_name'  => esc_html__( 'Handily Schedule', 'admin menu', 'handily' ),
    'name_admin_bar' => _x( 'Handily Schedule', 'add new on admin bar', 'handily' ),
    'add_new' => _x( 'Add New', 'Schedule', 'handily' ),
    'add_new_item' => esc_html__( 'Add New Schedule', 'handily' ),
    'new_item'  => esc_html__( 'New Schedule', 'handily' ),
    'edit_item' => esc_html__( 'Edit Schedule', 'handily' ),
    'view_item' => esc_html__( 'View Schedule', 'handily' ),
    'all_items' => esc_html__( 'All Schedule', 'handily' ),
    'search_items' => esc_html__( 'Search Schedule', 'handily' ),
    'parent_item_colon'  => esc_html__( 'Parent Schedule:', 'handily' ),
    'not_found' => esc_html__( 'No Schedule found.', 'handily' ),
    'not_found_in_trash' => esc_html__( 'No Schedule found in Trash.', 'handily' )
   );

$hr_args = array(
    'labels'             => $r_labels,
    'description'        => esc_html__( 'Description.', 'handily' ),
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => false,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'schedule' ),
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'menu_icon'          => 'dashicons-video-alt3',
    'supports'           => array( 'title', 'editor', 'author')
   );
register_post_type('schedule', $hr_args );
  /* Add new taxonomy, make it hierarchical (like categories) */
  $rty_labels = array(
    'name'              => esc_html__( 'Schedule Types', 'handily' ),
    'singular_name'     => esc_html__( 'Schedule Type', 'handily' ),
    'search_items'      => esc_html__( 'Search Schedule Types', 'handily' ),
    'all_items'         => esc_html__( 'All Schedule Types', 'handily' ),
    'parent_item'       => esc_html__( 'Parent Schedule Type', 'handily' ),
    'parent_item_colon' => esc_html__( 'Parent Schedule Type:', 'handily' ),
    'edit_item'         => esc_html__( 'Edit Schedule Type', 'handily' ),
    'update_item'       => esc_html__( 'Update Schedule Type', 'handily' ),
    'add_new_item'      => esc_html__( 'Add New Schedule Type', 'handily' ),
    'new_item_name'     => esc_html__( 'New Schedule Type Name', 'handily' ),
    'menu_name'         => esc_html__( 'Schedule Type', 'handily' ),
  );
  $rty_args = array(
    'hierarchical'      => true,
    'labels'            => $rty_labels,
    'show_ui'           => true,
    'show_admin_column' => true,
    'query_var'         => true,
    'rewrite'           => array('slug' => 'schedule-type'),
  );
register_taxonomy('schedule-type', array('schedule'), $rty_args );  